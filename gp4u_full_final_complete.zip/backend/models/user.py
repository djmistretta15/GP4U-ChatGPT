"""
SQLAlchemy models for user accounts.

Defines the User model along with associated profile and settings tables.
For brevity, only a subset of fields is implemented.
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean
from sqlalchemy.orm import relationship

from backend.core.database import Base


class User(Base):  # type: ignore[misc]
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime)

    # Relationships
    bookings = relationship("Booking", back_populates="user")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")

    # Relationship to marketplace orders
    orders = relationship("Order", back_populates="user", cascade="all, delete-orphan")

    # Community relationships
    # Users that this user is following (follower side of Follow)
    following = relationship(
        "Follow",
        foreign_keys="Follow.follower_id",
        back_populates="follower",
        cascade="all, delete-orphan",
    )
    # Users that follow this user (owner side of Follow)
    followers = relationship(
        "Follow",
        foreign_keys="Follow.owner_id",
        back_populates="owner",
        cascade="all, delete-orphan",
    )

    # Password reset tokens associated with this user.  When a user
    # requests a password reset, a token is created and linked via
    # ``user_id``.  Tokens are one‑time use and expire after a fixed
    # period.  See ``PasswordResetToken`` for details.
    password_reset_tokens = relationship(
        "PasswordResetToken",
        back_populates="user",
        cascade="all, delete-orphan",
    )