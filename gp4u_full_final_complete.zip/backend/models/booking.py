"""
SQLAlchemy model for bookings of GPUs.

Stores the start and end times of a rental as well as the associated
user and GPU.  Additional fields (e.g. status, total price) can be added
for a complete implementation.
"""

from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    gpu_id = Column(Integer, ForeignKey("gpus.id"), nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)

    # Relationships
    user = relationship("User", back_populates="bookings")
    gpu = relationship("GPU", back_populates="bookings")
    # A booking may have one associated payment
    payment = relationship("Payment", back_populates="booking", uselist=False)
    # A booking can have multiple reviews
    reviews = relationship("Review", back_populates="booking", cascade="all, delete-orphan")
    # A booking may have multiple disputes
    disputes = relationship("Dispute", back_populates="booking", cascade="all, delete-orphan")