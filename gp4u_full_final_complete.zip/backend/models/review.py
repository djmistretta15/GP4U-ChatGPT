"""
SQLAlchemy model for reviews and ratings of GPU rentals.

Each review belongs to a booking and stores a rating and optional
comment.  Additional fields such as timestamps could be added.
"""

from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Review(Base):
    __tablename__ = "reviews"

    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    rating = Column(Integer, nullable=False)
    comment = Column(String)

    booking = relationship("Booking", back_populates="reviews")