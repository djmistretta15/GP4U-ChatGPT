"""
SQLAlchemy model for jobs in the GPU job queue.

Jobs represent tasks submitted by users to run on a GPU.  Each job has
an associated command (describing the workload), a status and
timestamps for creation and execution.  In a full system, jobs would
be scheduled onto GPUs and executed asynchronously via a task
orchestration framework.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from backend.core.database import Base


class JobStatus(str, Enum):
    """Enumeration of possible job statuses."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Job(Base):  # type: ignore[misc]
    """Database model for a GPU job."""

    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    gpu_id = Column(Integer, ForeignKey("gpus.id"), nullable=False)
    command = Column(String, nullable=False)
    status = Column(String(20), nullable=False, default=JobStatus.PENDING.value)
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    ended_at = Column(DateTime, nullable=True)

    # Relationships
    user = relationship("User")
    gpu = relationship("GPU")