"""
SQLAlchemy model definition for contracts.

Contracts represent agreements between a renter and a GPU provider to
utilise a specific GPU for a period of time under a particular
pricing model.  A contract can be of type ``fixed`` (using the
provider's base price) or ``spot`` (using a dynamic, demand-based
price).  Contracts capture the agreed price, the start and end
timestamps and current status.  This model can be extended with
additional terms (e.g. cancellation policies) as the system evolves.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import relationship

from backend.core.database import Base


class ContractStatus(str, Enum):
    """Enumeration of possible contract states."""

    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class ContractType(str, Enum):
    """Enumeration of contract types."""

    FIXED = "fixed"
    SPOT = "spot"


class Contract(Base):  # type: ignore[misc]
    """Database model representing a rental contract for a GPU."""

    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    gpu_id = Column(Integer, ForeignKey("gpus.id"), nullable=False)
    contract_type = Column(String(20), nullable=False, default=ContractType.FIXED.value)
    price_per_hour = Column(Numeric(10, 2), nullable=False)
    start_time = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    status = Column(String(20), nullable=False, default=ContractStatus.ACTIVE.value)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User")
    gpu = relationship("GPU")

    def __repr__(self) -> str:
        return (
            f"<Contract id={self.id} user_id={self.user_id} gpu_id={self.gpu_id} "
            f"type={self.contract_type} price={self.price_per_hour} status={self.status}>"
        )