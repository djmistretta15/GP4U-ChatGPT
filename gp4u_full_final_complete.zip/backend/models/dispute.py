"""
SQLAlchemy model for disputes arising from bookings.

Captures issues raised by renters or owners and tracks the resolution
status.  Messages exchanged during the dispute could be modelled in a
separate table, but this simple model stores only a description and
status.
"""

from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Dispute(Base):
    __tablename__ = "disputes"

    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    description = Column(String, nullable=False)
    status = Column(String, default="open")

    booking = relationship("Booking", back_populates="disputes")