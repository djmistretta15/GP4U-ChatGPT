"""
Follow model for community features.

This model represents a follower–owner relationship between users.  Users can
follow GPU owners to receive updates about new GPUs, price changes or
community activities.  Each follow record links a follower to an owner and
records when the relationship was created.  Both follower and owner are
foreign keys to the ``users`` table since GPU owners are also users in
the system.
"""

from datetime import datetime

from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Follow(Base):  # type: ignore[misc]
    """Database model representing a follow relationship.

    ``follower_id`` references the user that is following, and ``owner_id``
    references the GPU owner being followed.  Both fields point to the
    ``users`` table.  A timestamp records when the follow was created.
    """

    __tablename__ = "follows"

    id = Column(Integer, primary_key=True, index=True)
    follower_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships back to User
    follower = relationship(
        "User",
        foreign_keys=[follower_id],
        back_populates="following",
    )
    owner = relationship(
        "User",
        foreign_keys=[owner_id],
        back_populates="followers",
    )