"""
SQLAlchemy model for password reset tokens.

This model stores one‑time tokens used to reset a user's password.  A
token is associated with a user and has an expiration timestamp.  The
``used`` flag indicates whether the token has been consumed.  When a
token is used to reset a password the service should mark it as used
to prevent reuse.  Expired tokens may be periodically purged from
the database by a background task (not implemented here).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship

from backend.core.database import Base


class PasswordResetToken(Base):  # type: ignore[misc]
    """Model for password reset tokens."""

    __tablename__ = "password_reset_tokens"

    id: int = Column(Integer, primary_key=True)
    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    token: str = Column(String, unique=True, nullable=False, index=True)
    expires_at: datetime = Column(DateTime, nullable=False)
    used: bool = Column(Boolean, default=False)

    # Relationship back to the user; allows ``token.user`` to access the
    # owning user instance.  The ``back_populates`` is defined on
    # ``User.password_reset_tokens`` in the user model.
    user = relationship("User", back_populates="password_reset_tokens")
