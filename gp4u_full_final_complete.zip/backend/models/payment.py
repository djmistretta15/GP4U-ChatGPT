"""
SQLAlchemy model for payments.

Represents a payment made for a booking, recording the amount and
status.  In a full implementation additional fields like currency and
payment processor response data could be included.
"""

from sqlalchemy import Column, Integer, Numeric, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    amount = Column(Numeric(10, 2), nullable=False)
    status = Column(String, default="pending", nullable=False)
    created_at = Column(DateTime)

    booking = relationship("Booking", back_populates="payment")