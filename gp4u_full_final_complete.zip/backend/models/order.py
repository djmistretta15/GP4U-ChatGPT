"""Order model for marketplace orders.

Represents a reservation or order placed by a renter for a specific GPU.  An
order records which GPU is requested, the quantity of GPU instances (for
future scaling), the price per hour the renter is willing to pay, the
current status of the order and timestamps.  This model could be
extended to support more complex bidding and matching logic in a
production implementation.
"""

from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import relationship

from backend.core.database import Base


class OrderStatus(str, Enum):
    """Enumeration of possible order statuses."""

    OPEN = "open"
    MATCHED = "matched"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class Order(Base):
    """Database model for marketplace orders."""

    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    gpu_id = Column(Integer, ForeignKey("gpus.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    quantity = Column(Integer, nullable=False, default=1)
    price_per_hour = Column(Numeric(10, 2), nullable=False)
    status = Column(String(20), nullable=False, default=OrderStatus.OPEN.value)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    gpu = relationship("GPU", back_populates="orders")
    user = relationship("User", back_populates="orders")

    # Bids placed on this order
    bids = relationship("Bid", back_populates="order", cascade="all, delete-orphan")