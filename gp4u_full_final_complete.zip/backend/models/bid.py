"""
SQLAlchemy model for marketplace bids.

This model represents a bid placed by a user on a marketplace order.
Each bid references the order it is associated with and the user who
placed it.  Bids have a monetary amount and a status to indicate
whether they are open, accepted or rejected.  In a full auction
implementation, additional fields such as expiration time could be
added.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import relationship

from backend.core.database import Base


class BidStatus(str, Enum):
    """Enumeration of possible bid statuses."""

    OPEN = "open"
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class Bid(Base):  # type: ignore[misc]
    """Database model for marketplace bids."""

    __tablename__ = "bids"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Numeric(10, 2), nullable=False)
    status = Column(String(20), nullable=False, default=BidStatus.OPEN.value)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    order = relationship("Order", back_populates="bids")
    user = relationship("User")
