"""
SQLAlchemy model definitions for GPUs available for rent.

Represents a GPU resource with associated metadata such as name,
manufacturer, memory capacity and hourly price.  Relationship fields
link to bookings and owner accounts.
"""

from sqlalchemy import Column, Integer, String, Float, Boolean
from sqlalchemy.orm import relationship

from backend.core.database import Base


class GPU(Base):
    __tablename__ = "gpus"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    manufacturer = Column(String, nullable=False)
    memory_gb = Column(Integer)
    price_per_hour = Column(Float, nullable=False)
    is_available = Column(Boolean, default=True)

    # Relationship to bookings
    bookings = relationship("Booking", back_populates="gpu")

    # Relationship to marketplace orders
    orders = relationship("Order", back_populates="gpu")