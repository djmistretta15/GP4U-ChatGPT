"""
SQLAlchemy model for notifications.

Represents a notification sent to a user, storing the message and
optional type such as email, push or in-app.
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    message = Column(String, nullable=False)
    type = Column(String, default="in_app")
    read = Column(Boolean, default=False)
    created_at = Column(DateTime)

    user = relationship("User", back_populates="notifications")