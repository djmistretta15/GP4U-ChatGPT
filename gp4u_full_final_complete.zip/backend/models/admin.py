"""
SQLAlchemy model for administrative users.

Used to record administrators who have elevated privileges such as
managing disputes or running analytics.
"""

from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import relationship

from backend.core.database import Base


class Admin(Base):
    __tablename__ = "admins"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_superadmin = Column(Boolean, default=False)

    # In a full implementation, relationships to activity logs or other
    # admin-specific tables would be defined here.