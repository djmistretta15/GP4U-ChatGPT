"""Tests for scheduler plugin."""

from datetime import datetime, timedelta

from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_scheduler_availability_invalid_range() -> None:
    """End time before start should return 400."""
    now = datetime.utcnow()
    params = {"start": now.isoformat(), "end": (now - timedelta(hours=1)).isoformat()}
    response = client.get(f"/api/v1/scheduler/1/availability", params=params)
    assert response.status_code == 400


def test_scheduler_availability_valid_range() -> None:
    """Valid range should return a boolean response."""
    now = datetime.utcnow()
    params = {"start": now.isoformat(), "end": (now + timedelta(hours=1)).isoformat()}
    response = client.get(f"/api/v1/scheduler/1/availability", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "available" in data
    assert isinstance(data["available"], bool)