"""Service unit tests."""

from backend.services.email_service import EmailService


def test_email_service_mock(capfd) -> None:
    """EmailService should log messages when no API key is configured."""
    service = EmailService(api_key=None)
    service.send_verification_email("test@example.com", "token123")
    out, _ = capfd.readouterr()
    assert "EmailService (mock)" in out

