"""
Scheduler plugin.

This plugin exposes endpoints to query GPU availability for arbitrary
time windows.  It leverages the ``SchedulerService`` to determine
whether requested slots overlap with existing bookings.  In the
future, endpoints could be added to create provisional bookings or
recommend alternative slots when a GPU is busy.
"""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.scheduler_service import SchedulerService

router = APIRouter(prefix="/api/v1/scheduler", tags=["Scheduler"])


@router.get("/{gpu_id}/availability", summary="Check GPU availability")
async def check_availability(
    gpu_id: int,
    start: datetime = Query(..., description="Start of desired booking window"),
    end: datetime = Query(..., description="End of desired booking window"),
    db: Session = Depends(get_db),
) -> dict[str, bool]:
    """Return whether the specified GPU is free between ``start`` and ``end``.

    This endpoint delegates to ``SchedulerService.is_available`` to
    determine if there are any overlapping bookings.  If ``end`` is
    earlier than ``start`` a ``400 Bad Request`` error is raised.
    """
    service = SchedulerService(db)
    if end <= start:
        raise HTTPException(status_code=400, detail="End time must be after start time")
    available = service.is_available(gpu_id, start, end)
    return {"gpu_id": gpu_id, "available": available}


def register(app) -> None:
    """Register the scheduler plugin with the FastAPI app."""
    app.include_router(router)