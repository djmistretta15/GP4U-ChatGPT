"""
Job queue plugin.

This plugin exposes endpoints for creating and managing jobs that run
on GPUs.  Jobs represent user workloads and transition through
pending, running and completed states.  Real execution of jobs would
be handled by an external scheduler; here we focus on job metadata
tracking.  Endpoints allow for job creation, retrieval and state
transitions.
"""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.job_service import JobService

router = APIRouter(prefix="/api/v1/jobs", tags=["Jobs"])


class JobCreateRequest(BaseModel):
    """Schema for creating a new job."""

    user_id: int
    gpu_id: int
    command: str


class JobOut(BaseModel):
    """Schema representing a job in responses."""

    id: int
    user_id: int
    gpu_id: int
    command: str
    status: str
    class Config:
        orm_mode = True


@router.get("/", response_model=List[JobOut], summary="List jobs")
async def list_jobs(db: Session = Depends(get_db)) -> List[JobOut]:
    """Return all jobs."""
    service = JobService(db)
    return service.list_jobs()


@router.get("/{job_id}", response_model=JobOut, summary="Get a job by ID")
async def get_job(job_id: int, db: Session = Depends(get_db)) -> JobOut:
    """Return a job by its ID."""
    service = JobService(db)
    job = service.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/", response_model=JobOut, status_code=status.HTTP_201_CREATED, summary="Create a new job")
async def create_job(payload: JobCreateRequest, db: Session = Depends(get_db)) -> JobOut:
    """Create a new job for a user on a specific GPU."""
    service = JobService(db)
    try:
        job = service.create_job(user_id=payload.user_id, gpu_id=payload.gpu_id, command=payload.command)
    except ValueError as exc:
        detail = str(exc)
        status_code = status.HTTP_404_NOT_FOUND if "Invalid" in detail else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail)
    return job


@router.post("/{job_id}/start", response_model=JobOut, summary="Start a job")
async def start_job(job_id: int, db: Session = Depends(get_db)) -> JobOut:
    """Mark a pending job as running."""
    service = JobService(db)
    try:
        job = service.start_job(job_id)
    except ValueError as exc:
        detail = str(exc)
        raise HTTPException(status_code=400, detail=detail)
    return job


@router.post("/{job_id}/complete", response_model=JobOut, summary="Complete a job")
async def complete_job(job_id: int, db: Session = Depends(get_db)) -> JobOut:
    """Mark a running job as completed."""
    service = JobService(db)
    try:
        job = service.complete_job(job_id)
    except ValueError as exc:
        detail = str(exc)
        raise HTTPException(status_code=400, detail=detail)
    return job


def register(app) -> None:
    """Register the job queue plugin with the FastAPI app."""
    app.include_router(router)