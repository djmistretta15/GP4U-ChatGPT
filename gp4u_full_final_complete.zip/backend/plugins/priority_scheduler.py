"""
Priority scheduler plugin.

This plugin provides an endpoint to trigger a simple job scheduling
algorithm.  The scheduler assigns pending jobs to available GPUs in
first‑in‑first‑out order and marks the jobs as running and GPUs as
unavailable.  Administrators or automated systems can call this
endpoint to move jobs from the pending queue into execution.  In
future versions this could be extended to support dynamic
prioritisation, batching and AI‑driven scheduling【398916126507635†L65-L75】【398916126507635†L126-L133】.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.priority_scheduler_service import PrioritySchedulerService

router = APIRouter(prefix="/api/v1/scheduler", tags=["Scheduler"])


@router.post("/priority-run", summary="Run the priority scheduler")
async def run_scheduler(db: Session = Depends(get_db)) -> dict[str, object]:
    """Assign pending jobs to available GPUs.

    Returns
    -------
    dict[str, object]
        A dictionary containing a list of assignments.  Each assignment
        specifies a ``job_id`` and ``gpu_id`` for scheduled jobs.
    """
    service = PrioritySchedulerService(db)
    assignments = service.run_scheduler()
    return {"assignments": assignments}


def register(app) -> None:
    """Register the priority scheduler plugin with the FastAPI application."""
    app.include_router(router)