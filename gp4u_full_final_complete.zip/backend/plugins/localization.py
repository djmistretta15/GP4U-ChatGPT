"""
Localization plugin.

This plugin exposes endpoints for retrieving supported languages and
translation strings.  It relies on the ``LocalizationService`` to
provide translation data.  Clients can use these endpoints to
dynamically load UI text for different languages and present a
localized experience to users who may feel left behind by rapid
technological change.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.services.localization_service import LocalizationService

router = APIRouter(prefix="/api/v1/localization", tags=["Localization"])


@router.get("/languages", summary="List supported languages")
async def list_languages() -> dict[str, object]:
    """Return a list of supported language codes."""
    service = LocalizationService()
    return {"languages": service.list_languages()}


@router.get("/{lang}", summary="Get translations for a language")
async def get_translations(lang: str) -> dict[str, object]:
    """Return translation strings for the specified language code."""
    service = LocalizationService()
    return {"translations": service.get_translations(lang)}


def register(app) -> None:
    """Register the localization plugin with the FastAPI app."""
    app.include_router(router)