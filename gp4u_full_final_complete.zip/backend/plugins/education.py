"""
Education plugin.

This plugin exposes endpoints that serve educational resources to
help users understand GPUs, AI workloads and how to utilise the
platform effectively.  It provides a curated list of topics and
associated descriptions or links.  In the future these resources
could be pulled from a CMS or wiki and localised for different
languages.
"""

from __future__ import annotations

from fastapi import APIRouter


router = APIRouter(prefix="/api/v1/education", tags=["Education"])


# Simple in-memory knowledge base.  Each topic maps to a
# dictionary containing a title and either a URL or plain text.  This
# can be expanded or replaced with dynamic content.
_RESOURCES = {
    "gpu_basics": {
        "title": "GPU Basics",
        "description": "An overview of what GPUs are, how they differ from CPUs, and why they are used for parallel computing.",
        "url": "https://en.wikipedia.org/wiki/Graphics_processing_unit",
    },
    "ml_workflows": {
        "title": "Machine Learning Workflows",
        "description": "A step-by-step guide to training and deploying ML models, including data preparation, model training and inference.",
        "url": "https://www.tensorflow.org/tutorials",
    },
    "cloud_rental": {
        "title": "Renting GPUs in the Cloud",
        "description": "Tips for choosing the right GPU for your workload, understanding pricing models and managing costs.",
        "url": "https://docs.datacrunch.io",
    },
    "sustainability": {
        "title": "Sustainability in AI",
        "description": "Learn about the environmental impact of AI and how sharing GPU resources can reduce waste and energy consumption.",
        "url": "https://blog.rloop.org/sustainable-ai",
    },
}


@router.get("/resources", summary="List available educational topics")
async def list_resources() -> list[dict]:
    """Return a list of available educational resources.

    Each item in the list contains a ``topic`` key along with a
    human-readable title and description.  Clients can use the topic
    identifier to fetch more detailed information.
    """
    return [
        {
            "topic": key,
            "title": value["title"],
            "description": value["description"],
        }
        for key, value in _RESOURCES.items()
    ]


@router.get("/{topic}", summary="Get details for an educational topic")
async def get_resource(topic: str) -> dict:
    """Return detailed information for a specific resource topic.

    Parameters
    ----------
    topic: str
        The identifier of the resource to retrieve.

    Returns
    -------
    dict
        Detailed information including title, description and URL.

    Raises
    ------
    HTTPException
        If the topic is not found.
    """
    resource = _RESOURCES.get(topic)
    if not resource:
        # Use a generic exception to avoid leaking sensitive info
        from fastapi import HTTPException  # Local import to avoid top-level dependency
        raise HTTPException(status_code=404, detail="Resource not found")
    return resource


def register(app) -> None:
    """Register the education plugin with the FastAPI application."""
    app.include_router(router)