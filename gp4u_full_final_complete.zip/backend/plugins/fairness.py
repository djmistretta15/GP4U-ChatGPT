"""
Fairness ranking plugin.

This plugin exposes an endpoint for retrieving fairness scores for GPU
owners.  Scores are computed by the ``FairnessService`` based on
average ratings and dispute rates.  Higher scores indicate a more
reliable and fair owner.  Administrators can use this information to
promote trustworthy providers or adjust platform policies.
"""

from __future__ import annotations

from typing import List, Dict

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.fairness_service import FairnessService

router = APIRouter(prefix="/api/v1/fairness", tags=["Fairness"])


@router.get("/scores", summary="Get fairness scores")
async def get_fairness_scores(db: Session = Depends(get_db)) -> List[Dict[str, object]]:
    """Return a list of fairness scores for all GPU owners."""
    service = FairnessService(db)
    return service.compute_scores()


def register(app) -> None:
    """Register the fairness plugin with the FastAPI app."""
    app.include_router(router)