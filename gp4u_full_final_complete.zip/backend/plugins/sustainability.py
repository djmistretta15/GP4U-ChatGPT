"""
Sustainability plugin.

Provides REST endpoints to estimate the environmental impact of GPU
usage.  Endpoints return approximate power consumption, carbon
emissions and offset costs for individual GPUs as well as aggregate
metrics across the entire platform.  Data is derived from a simple
heuristic and serves to raise awareness about environmental costs and
promote sustainable usage【29899153745735†L55-L72】.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.sustainability_service import SustainabilityService


router = APIRouter(prefix="/api/v1/sustainability", tags=["Sustainability"])


@router.get("/gpu/{gpu_id}", summary="Get sustainability metrics for a GPU")
async def get_gpu_sustainability(gpu_id: int, db: Session = Depends(get_db)) -> dict:
    """Return estimated power, carbon emissions and offset costs for a GPU.

    Parameters
    ----------
    gpu_id: int
        The GPU ID to analyse.
    db: Session
        SQLAlchemy session.

    Returns
    -------
    dict
        Sustainability metrics for the specified GPU.

    Raises
    ------
    HTTPException
        If the GPU does not exist.
    """
    service = SustainabilityService(db)
    try:
        metrics = service.get_gpu_metrics(gpu_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return metrics


@router.get("/summary", summary="Get aggregate sustainability metrics")
async def get_sustainability_summary(db: Session = Depends(get_db)) -> dict:
    """Return aggregate sustainability metrics for all GPUs.

    Parameters
    ----------
    db: Session
        SQLAlchemy session.

    Returns
    -------
    dict
        Total power draw, energy consumption, carbon emissions and
        offset cost across all GPUs.
    """
    service = SustainabilityService(db)
    return service.get_summary_metrics()


def register(app) -> None:
    """Register the sustainability plugin with the application."""
    app.include_router(router)