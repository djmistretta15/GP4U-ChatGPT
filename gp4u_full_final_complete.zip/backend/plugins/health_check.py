"""
Health check plugin.

This simple plugin exposes a basic liveness and readiness endpoint.
It reports the application status and the current state of feature
flags so that monitoring systems can verify that the service is
operational and configured as expected.  It is intentionally
lightweight and does not require database access.
"""

from __future__ import annotations

from fastapi import APIRouter

from backend.core.feature_flags import list_flags


router = APIRouter(prefix="/api/v1/health", tags=["Health"])


@router.get("/", summary="Health check")
async def health() -> dict:
    """Return application health status and feature flag states."""
    return {
        "status": "ok",
        "feature_flags": list_flags(),
    }


def register(app) -> None:
    """Register the health check plugin with the FastAPI application."""
    app.include_router(router)