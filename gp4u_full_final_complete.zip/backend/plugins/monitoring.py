"""
Monitoring plugin.

This plugin exposes an endpoint that returns aggregated statistics about
the platform.  Administrators and operators can use this information
to gauge the health and usage of the system.  For example, the
frontend admin dashboard can display these metrics in charts.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.monitoring_service import MonitoringService

router = APIRouter(prefix="/api/v1/monitoring", tags=["Monitoring"])


@router.get("/metrics", summary="Get platform metrics")
async def get_metrics(db: Session = Depends(get_db)) -> dict[str, float | int]:
    """Return aggregated usage metrics for the platform."""
    service = MonitoringService(db)
    return service.compute_metrics()


def register(app) -> None:
    """Register the monitoring plugin with the FastAPI app."""
    app.include_router(router)