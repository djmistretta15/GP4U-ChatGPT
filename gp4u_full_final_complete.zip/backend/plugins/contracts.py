"""
Contracts plugin.

This plugin exposes endpoints for creating and retrieving rental
contracts.  Contracts specify a pricing model (fixed or spot) and
duration, and tie a renter to a GPU.  The plugin utilises the
``ContractService`` to perform business logic and validate input.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.contract_service import ContractService


class ContractCreateRequest(BaseModel):
    """Schema for creating a new contract."""

    user_id: int = Field(..., description="ID of the renter")
    gpu_id: int = Field(..., description="ID of the GPU being rented")
    contract_type: str = Field(..., description="Type of contract ('fixed' or 'spot')")
    duration_hours: int = Field(1, ge=1, description="Length of contract in hours")


router = APIRouter(prefix="/api/v1/contracts", tags=["Contracts"])


@router.post("/", summary="Create a new rental contract")
async def create_contract(
    payload: ContractCreateRequest,
    db: Session = Depends(get_db),
) -> dict:
    """Create a new contract and return its details.

    Parameters
    ----------
    payload: ContractCreateRequest
        The contract creation request data.
    db: Session
        SQLAlchemy session.

    Returns
    -------
    dict
        A serialisable representation of the newly created contract.
    """
    service = ContractService(db)
    try:
        contract = service.create_contract(
            user_id=payload.user_id,
            gpu_id=payload.gpu_id,
            contract_type=payload.contract_type,
            duration_hours=payload.duration_hours,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {
        "id": contract.id,
        "user_id": contract.user_id,
        "gpu_id": contract.gpu_id,
        "contract_type": contract.contract_type,
        "price_per_hour": float(contract.price_per_hour),
        "start_time": contract.start_time.isoformat(),
        "end_time": contract.end_time.isoformat() if contract.end_time else None,
        "status": contract.status,
    }


@router.get("/{user_id}", summary="List all contracts for a user")
async def list_user_contracts(user_id: int, db: Session = Depends(get_db)) -> list[dict]:
    """Return all contracts belonging to a specific user.

    Parameters
    ----------
    user_id: int
        The user ID whose contracts to return.
    db: Session
        SQLAlchemy session.

    Returns
    -------
    list[dict]
        A list of contracts represented as dictionaries.
    """
    service = ContractService(db)
    contracts = service.get_contracts_by_user(user_id)
    return [
        {
            "id": c.id,
            "user_id": c.user_id,
            "gpu_id": c.gpu_id,
            "contract_type": c.contract_type,
            "price_per_hour": float(c.price_per_hour),
            "start_time": c.start_time.isoformat(),
            "end_time": c.end_time.isoformat() if c.end_time else None,
            "status": c.status,
        }
        for c in contracts
    ]


def register(app) -> None:
    """Register the contracts plugin with the FastAPI application."""
    app.include_router(router)