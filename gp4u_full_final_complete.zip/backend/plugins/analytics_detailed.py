"""
Detailed analytics plugin.

Exposes endpoints to retrieve deeper insights into platform usage,
including the most booked GPUs and top‑spending users.  These
endpoints support a ``limit`` query parameter to constrain the number
of results returned.
"""

from __future__ import annotations

from typing import List, Dict

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.analytics_detailed_service import AnalyticsDetailedService

router = APIRouter(prefix="/api/v1/analytics/detailed", tags=["Analytics"])


@router.get("/top-gpus", summary="Top GPUs by bookings")
async def top_gpus(
    limit: int = Query(5, ge=1, le=100, description="Maximum number of GPUs to return"),
    db: Session = Depends(get_db),
) -> List[Dict[str, object]]:
    """Return the GPUs with the most bookings."""
    service = AnalyticsDetailedService(db)
    return service.top_gpus_by_bookings(limit=limit)


@router.get("/top-users", summary="Top users by spending")
async def top_users(
    limit: int = Query(5, ge=1, le=100, description="Maximum number of users to return"),
    db: Session = Depends(get_db),
) -> List[Dict[str, object]]:
    """Return the users who have spent the most on GPU rentals."""
    service = AnalyticsDetailedService(db)
    return service.top_users_by_spending(limit=limit)


def register(app) -> None:
    """Register the detailed analytics plugin with the FastAPI app."""
    app.include_router(router)