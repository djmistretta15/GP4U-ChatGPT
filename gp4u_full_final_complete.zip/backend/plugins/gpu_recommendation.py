"""GPU recommendation plugin.

This plugin exposes an endpoint that accepts a free‑form description of
a workload or project and returns a recommended GPU configuration.
For now the recommendation uses a simple heuristic based on keyword
matching; in a production system this could be replaced with a more
sophisticated AI model or integration with a vector search service.

The plugin registers a single POST endpoint at ``/api/v1/recommendations``.
Clients should send a JSON body with a ``prompt`` field describing
their task.  The response contains a ``recommended_gpu`` object with
fields ``name``, ``manufacturer``, ``memory_gb`` and ``price_per_hour``.
"""

from fastapi import APIRouter, FastAPI, HTTPException
from pydantic import BaseModel, Field


class RecommendationRequest(BaseModel):
    """Schema for recommendation requests."""

    prompt: str = Field(..., title="Workload description", min_length=1)


class GPUInfo(BaseModel):
    """Basic representation of a GPU for recommendation results."""

    name: str
    manufacturer: str
    memory_gb: int
    price_per_hour: float


class RecommendationResponse(BaseModel):
    """Response schema for a GPU recommendation."""

    recommended_gpu: GPUInfo


router = APIRouter(prefix="/api/v1/recommendations", tags=["recommendations"])


@router.post("", response_model=RecommendationResponse)
async def recommend_gpu(request: RecommendationRequest) -> RecommendationResponse:
    """Return a GPU recommendation based on the provided prompt.

    The current implementation uses a set of simple keywords to map
    workloads to GPU classes.  More advanced logic could query the
    database, call external APIs or use AI models to interpret the
    prompt.  If no keywords are matched, a reasonable general‑purpose
    GPU is returned.

    Parameters
    ----------
    request:
        The recommendation request containing a ``prompt`` describing
        the user's workload.

    Returns
    -------
    RecommendationResponse
        An object containing the recommended GPU information.
    """
    prompt_lower = request.prompt.lower()

    # Simple keyword heuristics for demonstration purposes
    if any(keyword in prompt_lower for keyword in ["train", "training", "deep learning", "ai", "ml"]):
        gpu = GPUInfo(name="A100", manufacturer="NVIDIA", memory_gb=80, price_per_hour=5.0)
    elif any(keyword in prompt_lower for keyword in ["render", "video", "animation", "3d"]):
        gpu = GPUInfo(name="RTX 4090", manufacturer="NVIDIA", memory_gb=24, price_per_hour=3.5)
    elif any(keyword in prompt_lower for keyword in ["gaming", "esports", "streaming"]):
        gpu = GPUInfo(name="RX 7900 XTX", manufacturer="AMD", memory_gb=24, price_per_hour=2.5)
    elif any(keyword in prompt_lower for keyword in ["mining", "crypto"]):
        gpu = GPUInfo(name="CMP 90HX", manufacturer="NVIDIA", memory_gb=10, price_per_hour=1.8)
    else:
        # Default to a mid‑range general purpose GPU
        gpu = GPUInfo(name="RTX 3060", manufacturer="NVIDIA", memory_gb=12, price_per_hour=1.2)
    return RecommendationResponse(recommended_gpu=gpu)


def register(app: FastAPI) -> None:
    """Register the recommendation router with the FastAPI application."""
    app.include_router(router)