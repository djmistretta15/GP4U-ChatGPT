"""Plugin package for GP4U.

This package contains optional extensions that can be dynamically loaded into
the main application via ``backend.core.plugin_manager.load_plugins``. Each
module within this package that provides a ``register`` function is treated
as a plugin.  Plugins should be self‑contained and should not import or
manipulate other plugins directly.

For guidelines on designing plugins, see the discussion on plugin architecture
benefits and key principles【592182898178357†L40-L71】.
"""