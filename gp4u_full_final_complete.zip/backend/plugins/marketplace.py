"""Marketplace plugin for GPU rental orders.

This plugin exposes endpoints to create and list marketplace orders.
Renter clients can submit orders specifying which GPU they want, how
many instances they need and the price they are willing to pay.  The
list endpoint returns all current orders.  Matching and fulfilment
logic could be added in future iterations.

Endpoints:

* ``GET /api/v1/marketplace/orders`` – list all orders.
* ``POST /api/v1/marketplace/orders`` – create a new order.
"""

from fastapi import APIRouter, FastAPI, HTTPException, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from backend.core.database import SessionLocal
from backend.services.order_service import OrderService


class OrderCreateRequest(BaseModel):
    """Schema for creating a new marketplace order."""

    gpu_id: int = Field(..., title="GPU ID", ge=1)
    user_id: int = Field(..., title="User ID", ge=1)
    quantity: int = Field(1, title="Quantity", ge=1)
    price_per_hour: float = Field(..., title="Price per hour", gt=0)


class OrderOut(BaseModel):
    """Output schema for orders."""

    id: int
    gpu_id: int
    user_id: int
    quantity: int
    price_per_hour: float
    status: str

    class Config:
        orm_mode = True


router = APIRouter(prefix="/api/v1/marketplace", tags=["marketplace"])


def get_db() -> Session:
    """Dependency that yields a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/orders", response_model=list[OrderOut])
async def list_orders(db: Session = Depends(get_db)) -> list[OrderOut]:
    """Return all marketplace orders."""
    service = OrderService(db)
    orders = service.list_orders()
    return orders


@router.post("/orders", response_model=OrderOut, status_code=status.HTTP_201_CREATED)
async def create_order(request: OrderCreateRequest, db: Session = Depends(get_db)) -> OrderOut:
    """Create a new marketplace order.

    In a real system, you would validate that the user and GPU exist,
    check the user's balance or permissions, and possibly place the
    order into a queue for matching.  Here we simply persist the
    order to the database.
    """
    service = OrderService(db)
    order = service.create_order(
        gpu_id=request.gpu_id,
        user_id=request.user_id,
        quantity=request.quantity,
        price_per_hour=request.price_per_hour,
    )
    return order


def register(app: FastAPI) -> None:
    """Register marketplace routes with the application."""
    app.include_router(router)