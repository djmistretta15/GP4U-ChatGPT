"""
Pricing options plugin.

This plugin exposes an endpoint that returns two pricing strategies
for a given GPU: the base price as configured by the owner and a
dynamic price computed based on supply and demand within the
marketplace.  The endpoint delegates computation to the
``PricingOptionsService``.  Clients can use this information to
present renters with transparent pricing choices【408575178045826†L94-L102】.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.pricing_options_service import PricingOptionsService

router = APIRouter(prefix="/api/v1/pricing/options", tags=["Pricing"])


@router.get("/{gpu_id}", summary="Get pricing options for a GPU")
async def get_pricing_options(gpu_id: int, db: Session = Depends(get_db)) -> dict[str, float]:
    """Return base and dynamic pricing options for the specified GPU.

    Parameters
    ----------
    gpu_id: int
        The ID of the GPU for which to compute pricing options.
    db: Session
        SQLAlchemy session provided by dependency injection.

    Returns
    -------
    dict[str, float]
        A dictionary with ``base_price`` and ``dynamic_price`` keys.
    """
    service = PricingOptionsService(db)
    try:
        return service.get_price_options(gpu_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


def register(app) -> None:
    """Register the pricing options plugin with the FastAPI application."""
    app.include_router(router)