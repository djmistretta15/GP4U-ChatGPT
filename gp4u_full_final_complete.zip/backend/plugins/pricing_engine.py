"""Dynamic pricing engine plugin.

This plugin exposes an endpoint to suggest a rental price for a GPU
based on simple supply and demand heuristics.  The pricing strategy
implemented here is intentionally basic: it takes a GPU name along
with current supply and demand indicators and returns a recommended
hourly price.  In a production system this logic could be replaced
with machine learning models or real‑time market data.

Example request:

.. code-block:: json

    POST /api/v1/pricing
    {
      "name": "A100",
      "supply": 10,
      "demand": 15
    }

Example response:

.. code-block:: json

    {
      "name": "A100",
      "suggested_price": 5.75
    }

The plugin adheres to the plugin interface by exposing a ``register``
function that accepts a FastAPI app and mounts its router.
"""

from fastapi import APIRouter, FastAPI, HTTPException
from pydantic import BaseModel, Field


class PricingRequest(BaseModel):
    """Request model for price suggestions."""

    name: str = Field(..., title="GPU name", min_length=1)
    supply: int = Field(..., title="Available supply", ge=1)
    demand: int = Field(..., title="Current demand", ge=0)


class PricingResponse(BaseModel):
    """Response model containing suggested price."""

    name: str
    suggested_price: float


router = APIRouter(prefix="/api/v1/pricing", tags=["pricing"])


@router.post("", response_model=PricingResponse)
async def suggest_price(data: PricingRequest) -> PricingResponse:
    """Suggest a rental price based on supply and demand.

    The algorithm uses a base price for a handful of known GPUs.  If a
    GPU is unknown, a default base price is applied.  The price is
    adjusted by the ratio of demand to supply (clamped to a maximum
    multiplier) and rounded to two decimal places.

    Parameters
    ----------
    data: PricingRequest
        Contains the GPU name, available supply and current demand.

    Returns
    -------
    PricingResponse
        Contains the GPU name and a suggested hourly price.
    """
    # Define base prices for common GPUs.  These numbers are purely illustrative.
    base_prices = {
        "A100": 5.0,
        "RTX 4090": 3.5,
        "RTX 3060": 1.2,
        "RX 7900 XTX": 2.5,
        "CMP 90HX": 1.8,
    }
    base_price = base_prices.get(data.name, 2.0)

    # Calculate demand/supply ratio.  Avoid division by zero by ensuring supply >= 1.
    ratio = data.demand / data.supply if data.supply else 1.0
    # Clamp the multiplier between 0.5x (low demand, high supply) and 2.0x (high demand)
    multiplier = min(max(ratio, 0.5), 2.0)

    suggested_price = round(base_price * multiplier, 2)
    return PricingResponse(name=data.name, suggested_price=suggested_price)


def register(app: FastAPI) -> None:
    """Register the pricing router with the application."""
    app.include_router(router)