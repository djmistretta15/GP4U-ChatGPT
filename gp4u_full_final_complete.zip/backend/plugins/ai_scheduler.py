"""
AI scheduler plugin.

Expose an endpoint that runs the AI‑based scheduling heuristic to
assign pending jobs to GPUs.  The plugin delegates to the
``AISchedulerService`` for the actual logic.  This endpoint is
intended for demonstration; in a full system it would be backed by
predictive models and integrated with a continuous job orchestration
workflow【398916126507635†L126-L133】.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.ai_scheduler_service import AISchedulerService


router = APIRouter(prefix="/api/v1/scheduler/ai", tags=["Scheduling"])


@router.post("/run", summary="Run the AI scheduler")
async def run_ai_scheduler(db: Session = Depends(get_db)) -> list[dict[str, int]]:
    """Run the AI-driven scheduler and return job assignments.

    Returns a list of mappings from job IDs to GPU IDs.  If no
    assignments could be made, an empty list is returned.
    """
    service = AISchedulerService(db)
    assignments = service.run_ai_scheduler()
    return assignments


def register(app) -> None:
    """Register the AI scheduler plugin with the application."""
    app.include_router(router)