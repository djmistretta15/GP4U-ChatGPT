"""Matching engine plugin for marketplace orders.

This plugin exposes an endpoint that triggers the order matching
process.  When invoked, it attempts to assign available GPUs to open
orders using a simple first‑come‑first‑served algorithm implemented
in ``MatchingService``.  It returns a list of order IDs that were
successfully matched.

Endpoint:

* ``POST /api/v1/marketplace/match`` – match open orders with GPUs.
"""

from fastapi import APIRouter, FastAPI, Depends
from sqlalchemy.orm import Session

from backend.core.database import SessionLocal
from backend.services.matching_service import MatchingService


router = APIRouter(prefix="/api/v1/marketplace", tags=["marketplace"])


def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/match")
async def match_orders(db: Session = Depends(get_db)) -> dict[str, object]:
    """Trigger the matching process for open orders.

    Returns a dictionary containing the IDs of orders that were matched.
    If no orders are matched, an empty list is returned.
    """
    service = MatchingService(db)
    matched = service.match_orders()
    return {"matched_order_ids": [order.id for order in matched]}


def register(app: FastAPI) -> None:
    """Register the matching endpoint with the application."""
    app.include_router(router)