"""User level recommendations plugin.

This plugin exposes an API endpoint that returns a set of suggested UI
features for a given user experience level.  The goal is to support
progressive disclosure on the front‑end: beginners see a simplified
interface with only core actions, while intermediate and expert users
unlock additional analytics and advanced controls.  By centralizing
these recommendations in a plugin, the platform can evolve without
hard‑coding logic into the client.

Example:

.. code-block::

    GET /api/v1/user-levels/beginner

    {
      "level": "beginner",
      "features": ["search", "book", "pay", "notifications"]
    }

Supported levels are ``beginner``, ``intermediate`` and ``expert``.  A
``404`` is returned for unknown levels.  Downstream clients can use
these lists to conditionally render menus, tabs or pages appropriate
for the selected experience level.
"""

from fastapi import APIRouter, FastAPI, HTTPException


router = APIRouter(prefix="/api/v1/user-levels", tags=["user-levels"])


@router.get("/{level}")
async def get_user_level(level: str) -> dict[str, object]:
    """Return recommended features for the given user level.

    The returned dictionary contains the canonical level string and a list
    of feature identifiers that the front‑end can use to build menus.
    If an unrecognised level is requested, a ``404`` error is raised.

    Parameters
    ----------
    level:
        The user experience level.  Must be one of ``beginner``,
        ``intermediate`` or ``expert`` (case insensitive).

    Returns
    -------
    dict[str, object]:
        A JSON‑serialisable dictionary with the keys ``level`` and
        ``features``.
    """
    level = level.lower()
    if level == "beginner":
        return {
            "level": "beginner",
            # Core actions for new users: simple search and booking flow.
            "features": ["search", "book", "pay", "notifications"],
        }
    elif level == "intermediate":
        return {
            "level": "intermediate",
            # Unlock analytics and GPU management for users familiar with the system.
            "features": [
                "search",
                "book",
                "pay",
                "notifications",
                "analytics",
                "gpu_management",
            ],
        }
    elif level == "expert":
        return {
            "level": "expert",
            # Full control: advanced analytics, custom pricing and API access.
            "features": [
                "search",
                "book",
                "pay",
                "notifications",
                "analytics",
                "gpu_management",
                "custom_pricing",
                "api_access",
            ],
        }
    else:
        raise HTTPException(status_code=404, detail=f"Unknown user level '{level}'")


def register(app: FastAPI) -> None:
    """Register the user level router with the FastAPI application."""
    app.include_router(router)