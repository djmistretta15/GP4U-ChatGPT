"""
Community plugin.

This plugin exposes endpoints for users to follow and unfollow GPU
owners and to list the owners they are following.  It uses
authentication to identify the current user and delegates logic to the
``CommunityService``.  These endpoints enable social features that
encourage community engagement and keep users informed about their
favourite providers.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.auth import get_current_user
from backend.core.database import get_db
from backend.services.community_service import CommunityService

router = APIRouter(prefix="/api/v1/community", tags=["Community"])


@router.post("/follow/{owner_id}", summary="Follow a GPU owner")
async def follow_owner(
    owner_id: int,
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict[str, int]:
    """Create a follow relationship between the current user and an owner.

    Parameters
    ----------
    owner_id: int
        The ID of the owner to follow.
    user: dict
        The current user payload decoded from the JWT.  Contains the user ID.
    db: Session
        SQLAlchemy session injected via dependency.

    Returns
    -------
    dict[str, int]
        A dictionary containing the follower and owner IDs.
    """
    follower_id = int(user.get("id"))
    service = CommunityService(db)
    follow = service.follow_owner(follower_id, owner_id)
    return {"follower_id": follow.follower_id, "owner_id": follow.owner_id}


@router.delete("/follow/{owner_id}", summary="Unfollow a GPU owner")
async def unfollow_owner(
    owner_id: int,
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict[str, str]:
    """Remove a follow relationship between the current user and an owner."""
    follower_id = int(user.get("id"))
    service = CommunityService(db)
    service.unfollow_owner(follower_id, owner_id)
    return {"detail": "unfollowed"}


@router.get("/following", summary="List followed owners")
async def list_following(
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    """Return the list of owner IDs that the current user is following."""
    follower_id = int(user.get("id"))
    service = CommunityService(db)
    owners = service.list_following(follower_id)
    return {"following": owners}


def register(app) -> None:
    """Register the community plugin with the FastAPI app."""
    app.include_router(router)