"""
Bidding plugin for the marketplace.

This plugin enables users to place bids on marketplace orders, view
existing bids and accept the highest bid.  The bidding system allows
GPU owners or platform operators to auction off compute time, and
runners to compete on price.  In a full implementation, bids would
include expiration times and owners would be notified asynchronously
when a bid is placed or accepted.
"""

from __future__ import annotations

from decimal import Decimal
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from pydantic import BaseModel, condecimal
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.bid_service import BidService
from backend.services.notification_service import NotificationService
from backend.models.order import Order

router = APIRouter(prefix="/api/v1/bidding", tags=["Bidding"])


class BidCreate(BaseModel):
    """Schema for placing a new bid."""

    user_id: int
    amount: condecimal(decimal_places=2, gt=0)


class BidOut(BaseModel):
    """Schema representing a bid in API responses."""

    id: int
    user_id: int
    amount: Decimal
    status: str

    class Config:
        orm_mode = True


@router.get("/orders/{order_id}/bids", response_model=List[BidOut], summary="List bids for an order")
async def list_bids(order_id: int, db: Session = Depends(get_db)) -> List[BidOut]:
    """Return all bids placed on the given order, highest first."""
    service = BidService(db)
    bids = service.list_bids(order_id)
    return bids


@router.post(
    "/orders/{order_id}/bids",
    response_model=BidOut,
    status_code=status.HTTP_201_CREATED,
    summary="Place a bid on an order",
)
async def place_bid(
    order_id: int,
    payload: BidCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
) -> BidOut:
    """Create a new bid for an order.

    Raises a 404 error if the order does not exist, or a 400 error
    if the order is not open for bidding.
    """
    service = BidService(db)
    try:
        bid = service.place_bid(order_id=order_id, user_id=payload.user_id, amount=payload.amount)
    except ValueError as exc:
        detail = str(exc)
        status_code = status.HTTP_404_NOT_FOUND if "not found" in detail.lower() else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail)
    # Send a notification to the owner of the order asynchronously
    # Determine order owner; if lookup fails, notification will not be sent
    order = db.query(Order).filter(Order.id == order_id).first()
    if order:
        notif_service = NotificationService(db)
        message = f"User {payload.user_id} placed a bid of {payload.amount} on your order {order_id}."
        background_tasks.add_task(notif_service.send_notification, user_id=order.user_id, message=message)
    return bid


@router.post(
    "/orders/{order_id}/accept-highest",
    response_model=BidOut,
    summary="Accept the highest bid on an order",
)
async def accept_highest_bid(
    order_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
) -> BidOut:
    """Accept the highest open bid on the specified order.

    This will mark the highest bid as accepted, reject all other open bids
    and update the order's price and status.  If no bids exist, a 404
    error is returned.
    """
    service = BidService(db)
    bid = service.accept_highest_bid(order_id)
    if not bid:
        raise HTTPException(status_code=404, detail="No open bids to accept")
    # Send notifications to the winner and the order owner
    order = db.query(Order).filter(Order.id == order_id).first()
    notif_service = NotificationService(db)
    if order:
        # Notify owner that the bid was accepted
        message_owner = f"The highest bid for your order {order_id} has been accepted at {bid.amount}."
        background_tasks.add_task(notif_service.send_notification, user_id=order.user_id, message=message_owner)
    # Notify winning bidder
    message_winner = f"Your bid of {bid.amount} on order {order_id} has been accepted."
    background_tasks.add_task(notif_service.send_notification, user_id=bid.user_id, message=message_winner)
    return bid


def register(app) -> None:
    """Register the bidding plugin with the FastAPI app."""
    app.include_router(router)