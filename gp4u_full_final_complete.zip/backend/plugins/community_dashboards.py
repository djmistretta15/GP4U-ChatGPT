"""Community dashboards plugin.

This plugin provides API endpoints for community‑specific dashboards (e.g.
Twitch streamers, eSports teams, crypto miners, YouTubers). The goal is to
demonstrate how the platform can be extended to accommodate different user
communities without modifying core code. Each community may have unique
metrics or views relevant to its domain.  For now, this plugin exposes
placeholder endpoints that return simple JSON structures. These can later be
extended or replaced with fully featured dashboards.

Example:

.. code-block::

    GET /api/v1/dashboards/twitch

    {
      "community": "twitch",
      "metrics": {
        "live_streams": 12,
        "peak_viewers": 3500,
        "average_gpu_utilization": 0.82
      }
    }

The plugin adheres to the plugin interface by exposing a ``register`` function
that accepts a FastAPI application. During registration it mounts its router
under ``/api/v1/dashboards``.
"""

from fastapi import APIRouter, FastAPI, HTTPException

router = APIRouter(prefix="/api/v1/dashboards", tags=["dashboards"])


@router.get("/{community}")
async def get_community_dashboard(community: str):
    """Return a placeholder dashboard for the given community.

    Supported communities: twitch, esports, crypto, youtube.  Unknown
    communities result in a 404.  In a real implementation this function
    would query analytics services and aggregate metrics specific to the
    community.  The returned structure is intentionally simple and serves
    only as a demonstration.
    """
    community = community.lower()
    if community == "twitch":
        return {
            "community": "twitch",
            "metrics": {
                "live_streams": 12,
                "peak_viewers": 3500,
                "average_gpu_utilization": 0.82,
            },
        }
    elif community == "esports":
        return {
            "community": "esports",
            "metrics": {
                "active_matches": 5,
                "top_team": "Team Alpha",
                "average_frame_rate": 144,
            },
        }
    elif community == "crypto":
        return {
            "community": "crypto",
            "metrics": {
                "mining_rigs": 20,
                "hash_rate": "4.5 GH/s",
                "power_consumption_kwh": 120.5,
            },
        }
    elif community == "youtube":
        return {
            "community": "youtube",
            "metrics": {
                "active_creators": 8,
                "total_views_today": 28000,
                "average_render_time_seconds": 320,
            },
        }
    else:
        raise HTTPException(status_code=404, detail=f"Unknown community '{community}'")


def register(app: FastAPI) -> None:
    """Register the community dashboards router with the application."""
    app.include_router(router)