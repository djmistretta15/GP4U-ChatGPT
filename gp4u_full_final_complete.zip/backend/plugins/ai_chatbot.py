"""AI assistant chatbot plugin.

This plugin provides a simple endpoint that accepts a natural language prompt
describing a workload and returns a recommended GPU from the marketplace. It
demonstrates how the core platform can be extended with intelligent
functionality without modifying existing services. In practice, you could
integrate a large language model or vector search backend to parse the prompt
and match it to GPU capabilities. Here we implement a minimal heuristic based
on keyword matching and available GPUs in the database.

Usage:

.. code-block::

    POST /api/v1/chatbot

    {
        "prompt": "I need to train a large AI model"
    }

    Response:
    {
        "recommended_gpu": {
            "id": 2,
            "name": "A100",
            "manufacturer": "Nvidia",
            "memory_gb": 40,
            "price_per_hour": 3.5
        }
    }

The plugin uses the existing ``GPUService`` and database session to fetch
available GPUs and select one that best matches the user's needs.  A more
sophisticated implementation could leverage AI models and take user
constraints into account.
"""

from fastapi import APIRouter, Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.services.gpu_service import GPUService
from backend.schemas.gpu import GPURead

router = APIRouter(prefix="/api/v1", tags=["chatbot"])


class ChatbotRequest(BaseModel):
    """Request schema for the chatbot endpoint."""

    prompt: str = Field(..., description="Natural language description of your workload")


class ChatbotResponse(BaseModel):
    """Response schema returning a recommended GPU."""

    recommended_gpu: GPURead


def select_gpu_for_prompt(prompt: str, service: GPUService) -> GPURead:
    """Naively select a GPU based on keywords in the prompt.

    This is a placeholder for a more advanced matching algorithm. It looks for
    keywords indicating compute intensity (e.g., 'train', 'render', 'game')
    and returns the GPU with the highest memory or cheapest price depending on
    the context. If no GPUs are available, it raises an exception.

    Parameters
    ----------
    prompt:
        The natural language prompt provided by the user.
    service:
        An instance of ``GPUService`` used to retrieve available GPUs.

    Returns
    -------
    GPURead
        A Pydantic model representing the selected GPU.
    """
    prompt_lower = prompt.lower()
    gpus = service.list_gpus()
    if not gpus:
        raise HTTPException(status_code=404, detail="No GPUs available")

    # Heuristic selection: more memory for AI training, cheaper price for mining
    if any(keyword in prompt_lower for keyword in ["train", "ai", "deep learning"]):
        selected = max(gpus, key=lambda g: g.memory_gb)
    elif any(keyword in prompt_lower for keyword in ["render", "video", "editing"]):
        # Choose highest memory for rendering too
        selected = max(gpus, key=lambda g: g.memory_gb)
    elif any(keyword in prompt_lower for keyword in ["mine", "crypto", "hash"]):
        selected = min(gpus, key=lambda g: g.price_per_hour)
    elif any(keyword in prompt_lower for keyword in ["game", "esports", "stream"]):
        # Balanced: moderate memory and price
        selected = max(gpus, key=lambda g: (g.memory_gb / g.price_per_hour))
    else:
        # Default: pick the first available GPU
        selected = gpus[0]

    # Convert SQLAlchemy model to Pydantic schema
    return GPURead.from_orm(selected)


@router.post("/chatbot", response_model=ChatbotResponse)
def chat_with_bot(request: ChatbotRequest, db: Session = Depends(get_db)) -> ChatbotResponse:
    """Handle a prompt and return a GPU recommendation.

    This endpoint instantiates a ``GPUService`` using the provided database
    session, selects an appropriate GPU based on the prompt, and returns it.
    """
    service = GPUService(db)
    recommended = select_gpu_for_prompt(request.prompt, service)
    return ChatbotResponse(recommended_gpu=recommended)


def register(app: FastAPI) -> None:
    """Register the chatbot router with the application."""
    app.include_router(router)