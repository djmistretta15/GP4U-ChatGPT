"""Advanced GPU search plugin.

Extends the simple search functionality by allowing clients to filter
GPUs based on memory and price ranges in addition to name or
manufacturer.  All query parameters are optional; omitted filters are
ignored.  The endpoint is registered under
``/api/v1/search/gpus/advanced``.
"""

from fastapi import APIRouter, FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from backend.core.database import SessionLocal
from backend.models.gpu import GPU
from backend.schemas.gpu import GPURead


router = APIRouter(prefix="/api/v1/search", tags=["search"])


def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/gpus/advanced", response_model=list[GPURead])
async def advanced_search_gpus(
    q: str | None = None,
    min_memory: int | None = None,
    max_memory: int | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
    db: Session = Depends(get_db),
) -> list[GPU]:
    """Advanced search for GPUs with optional filters.

    Parameters
    ----------
    q: str | None
        Search term matching GPU name or manufacturer (case insensitive).
    min_memory: int | None
        Minimum memory (GB) required.
    max_memory: int | None
        Maximum memory (GB) allowed.
    min_price: float | None
        Minimum price per hour.
    max_price: float | None
        Maximum price per hour.

    Returns
    -------
    list[GPU]:
        List of GPUs satisfying the filters.
    """
    query = db.query(GPU)
    # Name/manufacturer filter
    if q:
        query = query.filter(
            or_(GPU.name.ilike(f"%{q}%"), GPU.manufacturer.ilike(f"%{q}%"))
        )
    # Memory filters
    if min_memory is not None:
        query = query.filter(GPU.memory_gb >= min_memory)
    if max_memory is not None:
        query = query.filter(GPU.memory_gb <= max_memory)
    # Price filters
    if min_price is not None:
        query = query.filter(GPU.price_per_hour >= min_price)
    if max_price is not None:
        query = query.filter(GPU.price_per_hour <= max_price)
    return query.all()


def register(app: FastAPI) -> None:
    """Register the advanced search router with the application."""
    app.include_router(router)