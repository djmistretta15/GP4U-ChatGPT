"""Analytics overview plugin.

This plugin provides a high‑level overview of key metrics across the
GP4U platform.  It aggregates counts of users, GPUs, bookings,
payments and reviews from the database, returning them in a single
payload.  Such an endpoint can drive administrative dashboards or
health monitoring tools.

The plugin registers a GET endpoint at ``/api/v1/analytics-overview``.
Consumers can poll this endpoint to display up‑to‑date statistics.
"""

from fastapi import APIRouter, FastAPI
from sqlalchemy.orm import Session

from backend.core.database import SessionLocal
from backend.models.user import User
from backend.models.gpu import GPU
from backend.models.booking import Booking
from backend.models.payment import Payment
from backend.models.review import Review


router = APIRouter(prefix="/api/v1/analytics-overview", tags=["analytics"])


@router.get("")
async def analytics_overview() -> dict[str, object]:
    """Return aggregated counts of various platform entities.

    The current implementation performs simple count queries.  In a
    production system you might cache these values or compute them
    asynchronously to reduce load on the database.

    Returns
    -------
    dict[str, object]:
        A dictionary containing counts of users, GPUs, bookings,
        payments and reviews.
    """
    db: Session = SessionLocal()
    try:
        users_count = db.query(User).count()
        gpus_count = db.query(GPU).count()
        bookings_count = db.query(Booking).count()
        payments_count = db.query(Payment).count()
        reviews_count = db.query(Review).count()
    finally:
        db.close()
    return {
        "users": users_count,
        "gpus": gpus_count,
        "bookings": bookings_count,
        "payments": payments_count,
        "reviews": reviews_count,
    }


def register(app: FastAPI) -> None:
    """Register the analytics overview router with the application."""
    app.include_router(router)