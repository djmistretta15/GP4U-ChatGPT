"""
Feature flags API plugin.

This plugin exposes endpoints for inspecting the current state of feature
flags.  Clients can retrieve a list of all defined flags and check
whether a specific flag is enabled.  Feature flags allow the system
administrator to toggle functionality on or off without redeploying
code.  Flags are defined and managed in ``backend.core.feature_flags``.

Endpoints
---------

``GET /api/v1/feature-flags/``
    Return a mapping of all known flags to their enabled/disabled state.

``GET /api/v1/feature-flags/{flag_name}``
    Return whether a specific flag is enabled.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from backend.core.feature_flags import list_flags, is_enabled

router = APIRouter(prefix="/api/v1/feature-flags", tags=["Feature Flags"])


@router.get("/", summary="List all feature flags")
async def get_feature_flags() -> dict[str, bool]:
    """Return a mapping of all known feature flags and their statuses."""
    return list_flags()


@router.get("/{flag_name}", summary="Get a specific feature flag")
async def get_feature_flag(flag_name: str) -> dict[str, object]:
    """Return the enabled status of a specific feature flag.

    Parameters
    ----------
    flag_name: str
        The name of the feature flag to query.  Case insensitive.

    Returns
    -------
    dict[str, object]
        A dictionary containing the flag name and its boolean status.
    """
    enabled = is_enabled(flag_name)
    return {"feature": flag_name, "enabled": enabled}


def register(app) -> None:
    """Register the feature flags plugin with the FastAPI application.

    This mounts the router defined in this module on the main application.

    Parameters
    ----------
    app: FastAPI
        The main FastAPI application instance.
    """
    app.include_router(router)