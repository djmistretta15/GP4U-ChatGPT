"""
GPU API endpoints.

Allows clients to list available GPUs and create new GPU entries.
These endpoints illustrate typical CRUD operations using FastAPI and
SQLAlchemy.  Authentication is not enforced in this simplified example.
"""

from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.schemas.gpu import GPURead, GPUCreate
from backend.services.gpu_service import GPUService

router = APIRouter(prefix="/api/v1/gpus", tags=["gpus"])


@router.get("/", response_model=List[GPURead])
def list_gpus(db: Session = Depends(get_db)):
    """Return a list of all GPUs."""
    service = GPUService(db)
    return service.list_gpus()


@router.post("/", response_model=GPURead, status_code=201)
def create_gpu(gpu: GPUCreate, db: Session = Depends(get_db)):
    """Create a new GPU entry."""
    service = GPUService(db)
    try:
        new_gpu = service.create_gpu(
            name=gpu.name,
            manufacturer=gpu.manufacturer,
            memory_gb=gpu.memory_gb,
            price_per_hour=gpu.price_per_hour,
        )
        return new_gpu
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))