"""
Dispute API endpoints.

Provides endpoints to create disputes for bookings and list all disputes.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.schemas.dispute import DisputeRead, DisputeCreate
from backend.services.dispute_service import DisputeService

router = APIRouter(prefix="/api/v1/disputes", tags=["disputes"])


@router.get("/", response_model=list[DisputeRead])
def list_disputes(db: Session = Depends(get_db)):
    """List all disputes."""
    service = DisputeService(db)
    return service.list_disputes()


@router.post("/", response_model=DisputeRead, status_code=201)
def create_dispute(dispute: DisputeCreate, db: Session = Depends(get_db)):
    """Create a dispute for a booking."""
    service = DisputeService(db)
    try:
        new_dispute = service.create_dispute(
            booking_id=dispute.booking_id,
            description=dispute.description,
        )
        return new_dispute
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

