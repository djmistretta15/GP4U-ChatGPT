"""
User profile API endpoints.

Provides basic endpoints to retrieve and update user profiles.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.models.user import User
from backend.schemas.user import UserRead, UserCreate

router = APIRouter(prefix="/api/v1/users", tags=["users"])


@router.get("/{user_id}", response_model=UserRead)
def get_user_profile(user_id: int, db: Session = Depends(get_db)):
    """Retrieve a user profile by its ID."""
    user = db.query(User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.put("/{user_id}", response_model=UserRead)
def update_user_profile(user_id: int, update: UserCreate, db: Session = Depends(get_db)):
    """Update a user profile."""
    user = db.query(User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.email = update.email
    # For simplicity, we update the password directly; in practice, hash the password
    user.hashed_password = update.password
    db.commit()
    db.refresh(user)
    return user

