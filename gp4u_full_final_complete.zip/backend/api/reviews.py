"""
Review API endpoints.

Allows creation and listing of reviews for bookings.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.schemas.review import ReviewRead, ReviewCreate
from backend.services.review_service import ReviewService

router = APIRouter(prefix="/api/v1/reviews", tags=["reviews"])


@router.get("/", response_model=list[ReviewRead])
def list_reviews(db: Session = Depends(get_db)):
    """List all reviews."""
    service = ReviewService(db)
    return service.list_reviews()


@router.post("/", response_model=ReviewRead, status_code=201)
def create_review(review: ReviewCreate, db: Session = Depends(get_db)):
    """Create a review for a booking."""
    service = ReviewService(db)
    try:
        new_review = service.create_review(
            booking_id=review.booking_id,
            rating=review.rating,
            comment=review.comment,
        )
        return new_review
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

