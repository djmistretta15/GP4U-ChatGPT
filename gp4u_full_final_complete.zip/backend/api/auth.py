"""
Authentication API endpoints.

Provides login functionality using email and password.  On successful
authentication a JWT token is returned.  A register endpoint can
also be implemented to allow new users to sign up.
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from fastapi import status
from fastapi import BackgroundTasks
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import verify_password, create_access_token, get_password_hash
from backend.models.user import User
from backend.schemas.auth import RegisterRequest, ForgotPasswordRequest, ResetPasswordRequest
from backend.schemas.user import UserRead, UserCreate
from backend.services.password_reset_service import PasswordResetService
from backend.services.email_service import EmailService

router = APIRouter(prefix="/api/v1/auth", tags=["authentication"])


@router.post("/login")
def login(email: str, password: str, db: Session = Depends(get_db)):
    """Authenticate a user and return a JWT token."""
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}


@router.post("/register", response_model=UserRead, status_code=status.HTTP_201_CREATED)
def register(
    request: RegisterRequest,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks | None = None,
):
    """Register a new user.

    Creates a new user account with the provided email and password.
    If the email is already in use a ``400 Bad Request`` error is
    returned.  The password is hashed using bcrypt before persisting
    the user.  In a production system this endpoint would send a
    verification email to confirm the user's ownership of the
    address.
    """
    existing = db.query(User).filter(User.email == request.email).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")
    user = User(email=request.email, hashed_password=get_password_hash(request.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    # Send a verification email in the background if possible.  A simple
    # one‑time token is generated for demonstration purposes.  In a
    # production system you would persist this token and verify it
    # through a dedicated verification endpoint.  Here we simply send
    # the email without storing the token.
    try:
        from backend.services.email_service import EmailService  # local import to avoid circular dep
        import secrets
        email_service = EmailService()
        verification_token = secrets.token_urlsafe(16)
        if background_tasks:
            background_tasks.add_task(
                email_service.send_verification_email,
                request.email,
                verification_token,
            )
        else:
            # Fallback to synchronous send if background tasks not provided
            email_service.send_verification_email(request.email, verification_token)
    except Exception:
        # Suppress any email sending errors; registration should succeed
        pass
    return user


@router.post("/forgot-password")
async def forgot_password(
    request: ForgotPasswordRequest,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks,
):
    """Initiate a password reset for the given email.

    If a user with the specified email exists, a reset token is
    created and an email is sent containing the reset link.  To avoid
    leaking user existence information the response is the same
    regardless of whether a user was found.
    """
    password_service = PasswordResetService(db)
    token = password_service.create_reset_token(request.email)
    if token:
        # Send email in background to avoid delaying response
        email_service = EmailService()
        background_tasks.add_task(email_service.send_password_reset_email, request.email, token)
    # Always return a generic message for privacy
    return {"detail": "If an account exists, a reset link has been sent"}


@router.post("/reset-password")
async def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    """Complete a password reset using a token and new password.

    The provided token must be valid, unused and unexpired.  If
    successful, the associated user's password is updated and the
    token is marked as used.  A 400 error is returned for invalid
    tokens.
    """
    password_service = PasswordResetService(db)
    success = password_service.verify_and_reset_password(request.token, request.password)
    if not success:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid or expired token")
    return {"detail": "Password has been reset"}