"""
Payment API endpoints.

Provides a basic endpoint to create a payment for a booking.  In a
production environment, this would integrate with Stripe or another
payment processor and handle webhooks to update payment status.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.schemas.payment import PaymentCreate, PaymentRead
from backend.services.payment_service import PaymentService

router = APIRouter(prefix="/api/v1/payments", tags=["payments"])


@router.post("/", response_model=PaymentRead, status_code=201)
def create_payment(payment: PaymentCreate, db: Session = Depends(get_db)):
    """Create a payment for a booking."""
    service = PaymentService(db)
    try:
        new_payment = service.create_payment(
            booking_id=payment.booking_id,
            amount=float(payment.amount),
        )
        return new_payment
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))