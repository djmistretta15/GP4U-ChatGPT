"""
Notification API endpoints.

Allows users to view and update notifications.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.schemas.notification import NotificationRead
from backend.services.notification_service import NotificationService

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


@router.get("/{user_id}", response_model=list[NotificationRead])
def list_notifications(user_id: int, db: Session = Depends(get_db)):
    """List notifications for a user."""
    service = NotificationService(db)
    return service.list_notifications(user_id)


@router.put("/{notification_id}", response_model=NotificationRead)
def mark_as_read(notification_id: int, db: Session = Depends(get_db)):
    """Mark a notification as read."""
    service = NotificationService(db)
    try:
        updated = service.mark_as_read(notification_id)
        return updated
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

