"""
Admin API endpoints.

Provides administrative endpoints for managing users and bookings.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.models.user import User
from backend.models.booking import Booking
from backend.schemas.user import UserRead
from backend.schemas.booking import BookingRead

router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


@router.get("/users", response_model=list[UserRead])
def list_users(db: Session = Depends(get_db)):
    """List all users."""
    return db.query(User).all()


@router.get("/bookings", response_model=list[BookingRead])
def list_bookings(db: Session = Depends(get_db)):
    """List all bookings."""
    return db.query(Booking).all()

