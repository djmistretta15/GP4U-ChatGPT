"""
Analytics API endpoints.

Returns aggregate metrics about the platform, such as total GPUs,
bookings and revenue.  Revenue is calculated as the sum of all payment
amounts.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.core.database import get_db
from backend.models.gpu import GPU
from backend.models.booking import Booking
from backend.models.payment import Payment
from backend.schemas.analytics import AnalyticsMetrics

router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])


@router.get("/metrics", response_model=AnalyticsMetrics)
def get_metrics(db: Session = Depends(get_db)):
    """Return aggregate platform metrics."""
    total_gpus = db.query(func.count(GPU.id)).scalar() or 0
    total_bookings = db.query(func.count(Booking.id)).scalar() or 0
    total_revenue = db.query(func.coalesce(func.sum(Payment.amount), 0)).scalar() or 0
    # For simplicity, average utilization is computed as total_bookings / total_gpus (if any)
    average_utilization = float(total_bookings) / total_gpus if total_gpus > 0 else 0.0
    return AnalyticsMetrics(
        total_gpus=total_gpus,
        total_bookings=total_bookings,
        total_revenue=float(total_revenue),
        average_utilization=average_utilization,
    )

