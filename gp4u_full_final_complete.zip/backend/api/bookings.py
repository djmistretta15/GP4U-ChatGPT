"""
Booking API endpoints.

Supports listing and creating bookings.  Each booking associates a
user with a GPU and records start and end times.  In a full
implementation additional validation (e.g. availability checks) and
authentication would be required.
"""

from typing import List
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.schemas.booking import BookingRead, BookingCreate
from backend.services.booking_service import BookingService

router = APIRouter(prefix="/api/v1/bookings", tags=["bookings"])


@router.get("/", response_model=List[BookingRead])
def list_bookings(db: Session = Depends(get_db)):
    """Return all bookings."""
    service = BookingService(db)
    return service.list_bookings()


@router.post("/", response_model=BookingRead, status_code=201)
def create_booking(booking: BookingCreate, db: Session = Depends(get_db)):
    """Create a new booking for a GPU between start_time and end_time."""
    service = BookingService(db)
    try:
        new_booking = service.create_booking(
            user_id=booking.user_id,
            gpu_id=booking.gpu_id,
            start_time=booking.start_time,
            end_time=booking.end_time,
        )
        return new_booking
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))