"""
Payout API endpoints.

Allows owners to request payouts of their accumulated earnings. In a
production system this would integrate with Stripe or another payout
provider and be restricted to authenticated owners. Here it simply
creates a payout via the `PayoutService` and returns a payout ID.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.services.payout_service import PayoutService


router = APIRouter(prefix="/api/v1/payouts", tags=["payouts"])


class PayoutRequest(BaseModel):
    account: str
    amount: float


@router.post("/", status_code=200)
def create_payout(req: PayoutRequest) -> dict:
    """Request a payout to the specified account."""
    if req.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    service = PayoutService()
    payout_id = service.create_payout(req.amount)
    return {"payout_id": payout_id}