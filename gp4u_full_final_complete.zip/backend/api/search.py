"""
Search API endpoints.

Provides simple search functionality across resources.  Currently
supports searching GPUs by name or manufacturer.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_

from backend.core.database import get_db
from backend.models.gpu import GPU
from backend.schemas.gpu import GPURead

router = APIRouter(prefix="/api/v1/search", tags=["search"])


@router.get("/gpus", response_model=list[GPURead])
def search_gpus(q: str, db: Session = Depends(get_db)):
    """Search GPUs by name or manufacturer containing the query."""
    if not q:
        raise HTTPException(status_code=400, detail="Query parameter q is required")
    results = db.query(GPU).filter(
        or_(GPU.name.ilike(f"%{q}%"), GPU.manufacturer.ilike(f"%{q}%"))
    ).all()
    return results

