"""
User settings API endpoints.

This module defines simple in‑memory endpoints for managing user
preferences such as notification settings, dark mode and timezone. In
a real application these settings would be stored persistently in the
database and associated with the ``User`` model. For demonstration
purposes the settings are stored in a global dictionary keyed by
``user_id``.
"""

from __future__ import annotations

from typing import Dict

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])


class UserSettings(BaseModel):
    """Schema for user preferences."""

    email_notifications: bool = True
    dark_mode: bool = False
    timezone: str = "UTC"


# In‑memory settings store keyed by user ID. In production this would be
# persisted in the database.
_settings_store: Dict[int, Dict[str, bool | str]] = {}


@router.get("/{user_id}", response_model=UserSettings)
def get_settings(user_id: int) -> UserSettings:
    """Retrieve settings for the specified user."""
    data = _settings_store.get(user_id)
    if not data:
        return UserSettings()  # return defaults
    return UserSettings(**data)


@router.put("/{user_id}", response_model=UserSettings)
def update_settings(user_id: int, settings: UserSettings) -> UserSettings:
    """Update settings for the specified user."""
    _settings_store[user_id] = settings.model_dump()
    return settings

