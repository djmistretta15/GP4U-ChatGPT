"""
Entry point for the FastAPI application.

Initialises the FastAPI app, includes the routers for authentication,
GPUs and bookings, and defines a simple health check endpoint.
"""

from fastapi import FastAPI

from backend.api import (
    auth,
    gpus,
    bookings,
    payments,
    disputes,
    reviews,
    notifications,
    search,
    analytics,
    settings,
    admin,
    user_profile,
    payouts,
)

# Import plugin loader
from backend.core.plugin_manager import load_plugins

app = FastAPI(title="GP4U API", version="0.1.0")

@app.get("/health")
async def health():
    """Return health status."""
    return {"status": "healthy"}

app.include_router(auth.router)
app.include_router(gpus.router)
app.include_router(bookings.router)
app.include_router(payments.router)
app.include_router(disputes.router)
app.include_router(reviews.router)
app.include_router(notifications.router)
app.include_router(search.router)
app.include_router(analytics.router)
app.include_router(settings.router)
app.include_router(admin.router)
app.include_router(user_profile.router)
app.include_router(payouts.router)

# Load any plugins present in backend/plugins
load_plugins(app)