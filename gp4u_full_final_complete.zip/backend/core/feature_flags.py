"""
Feature flag utilities.

This module provides a simple mechanism for enabling or disabling
functionality at runtime based on environment variables.  The goal of
feature flags is to allow incremental rollout of new features and
controlled experimentation.  Flags are defined in a central mapping
``_DEFAULT_FLAGS`` and can be overridden via environment variables
prefixed with ``FEATURE_``.  For example, to disable the pricing
engine, set ``FEATURE_PRICING_ENGINE=false`` in the environment.

The ``is_enabled`` function returns ``True`` if a feature is enabled,
consulting the environment variables first and falling back to
``_DEFAULT_FLAGS``.  The ``list_flags`` function returns a dictionary
of all known flags and their current statuses.
"""

from __future__ import annotations

import os
from typing import Dict

# Define the default state of all known feature flags.  Flags should
# correspond to plugin module names or other conditional behaviour in
# the application.  New flags can be added here to make them
# discoverable via the API.
_DEFAULT_FLAGS: Dict[str, bool] = {
    "community_dashboards": True,
    "pricing_engine": True,
    "analytics_overview": True,
    "marketplace": True,
    "matching_engine": True,
    "search_advanced": True,
    "gpu_recommendation": True,
    "user_levels": True,
    "ai_chatbot": True,
    "feature_flags": True,
    "monitoring": True,
    "scheduler": True,
    "bidding": True,
    "fairness": True,
    "analytics_detailed": True,
    "job_queue": True,
    # New plugins introduced by further enhancements
    "pricing_options": True,
    "priority_scheduler": True,
    "localization": True,
    "community": True,
    # Sustainability metrics plugin. Enables carbon footprint and energy
    # consumption endpoints to help users understand environmental impacts.
    "sustainability": True,
    # Contract management plugin. Allows creation and retrieval of
    # usage contracts (e.g. fixed vs spot pricing) between renters and
    # GPU providers.
    "contracts": True,
    # AI-driven scheduler plugin. Exposes a smart scheduler that
    # recommends GPU assignments based on workload characteristics. At
    # present this provides a simple heuristic but is designed to be
    # extended with ML models.
    "ai_scheduler": True,
    # Education plugin. Serves onboarding materials, tutorials and
    # curated resources to help new users learn about GPUs and AI
    # workloads.
    "education": True,
    # Health check plugin. Provides a simple health endpoint for
    # monitoring system status and loaded plugins. Can be disabled in
    # production if redundant.
    "health_check": True,
    # Additional flags may be added as new plugins or features are introduced.
}


def _parse_bool(value: str) -> bool:
    """Return a boolean value based on common truthy strings.

    Parameters
    ----------
    value: str
        The environment variable value to parse.

    Returns
    -------
    bool
        ``True`` if the string represents a truthy value; otherwise ``False``.
    """
    return value.lower() in {"1", "true", "yes", "on"}


def is_enabled(flag_name: str) -> bool:
    """Determine whether a feature flag is enabled.

    This checks for an environment variable named ``FEATURE_<FLAG_NAME>``,
    where ``<FLAG_NAME>`` is the upper‑case version of the flag.  If the
    environment variable is defined, its value will override the default.
    Otherwise the default value from ``_DEFAULT_FLAGS`` is returned.

    Parameters
    ----------
    flag_name: str
        The canonical name of the flag (case insensitive).

    Returns
    -------
    bool
        ``True`` if the flag is enabled, ``False`` otherwise.
    """
    env_var = f"FEATURE_{flag_name.upper()}"
    env_value = os.getenv(env_var)
    if env_value is not None:
        return _parse_bool(env_value)
    return _DEFAULT_FLAGS.get(flag_name, False)


def list_flags() -> Dict[str, bool]:
    """Return the current state of all known feature flags."""
    return {name: is_enabled(name) for name in _DEFAULT_FLAGS.keys()}
