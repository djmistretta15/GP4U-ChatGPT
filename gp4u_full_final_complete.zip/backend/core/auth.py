"""
Authentication dependencies for FastAPI routes.

Provides a dependency that extracts the current user from the Authorization
header.  In a real implementation this would query the database to fetch
the user record and verify credentials.  Here we provide a simplified
placeholder.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

from backend.core.security import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    """Return the current user from a JWT token.

    This simplified function decodes the token and returns the payload.
    In a real implementation you would verify the token and then
    retrieve the user from the database.
    """
    try:
        payload = decode_access_token(token)
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        return {"id": user_id}
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")