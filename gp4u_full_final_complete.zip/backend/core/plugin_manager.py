"""
Plugin management utilities.

This module defines a simple plugin loading mechanism that can be used to extend
the API without modifying core application code. Plugins reside in the
``backend/plugins`` package and must implement a ``register`` function that
takes a ``FastAPI`` application instance and performs whatever setup is
necessary (for example, mounting additional routers or registering event
handlers).

The plugin architecture follows the principles described in modern software
architecture guides: a host application exposes a stable interface, while
extensions are decoupled, modular and independently loadable.  Each plugin
should focus on a single concern and avoid side effects. See
https://arjancodes.com/blog/best-practices-for-decoupling-software-using-plugins/
for a discussion of the benefits of modularity and extensibility in plugin
design【592182898178357†L40-L71】.

Usage:

.. code-block:: python

    from backend.core.plugin_manager import load_plugins
    from fastapi import FastAPI

    app = FastAPI()
    load_plugins(app)

Plugins are discovered by inspecting the ``backend/plugins`` package for
modules with a callable ``register(app: FastAPI)`` symbol. If any plugin
raises an exception during import or registration, the error will be logged and
the plugin will be skipped to avoid impacting the core system.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from typing import Callable, Protocol

from fastapi import FastAPI

logger = logging.getLogger(__name__)


class PluginProtocol(Protocol):
    """Simple protocol that plugin modules can implement.

    A plugin module should define a ``register`` function conforming to this
    protocol. The function receives the main application and may mount
    additional routers, register event handlers, etc.
    """

    def register(self, app: FastAPI) -> None:
        ...


def load_plugins(app: FastAPI) -> None:
    """Dynamically discover and load plugins.

    This function scans the ``backend.plugins`` package for submodules and
    imports each module. If a module exposes a callable ``register`` attribute
    that accepts a ``FastAPI`` instance, it will be invoked with the provided
    application. Any exceptions during import or registration are logged and
    do not stop the loading of other plugins.

    Parameters
    ----------
    app:
        The FastAPI application to which plugins should register routes and
        behaviour.
    """
    try:
        import backend.plugins  # noqa: F401
    except ImportError:
        logger.warning("No plugins package found; skipping plugin loading")
        return

    package_name = 'backend.plugins'
    # Iterate over all modules in the backend.plugins package
    for finder, name, ispkg in pkgutil.iter_modules(importlib.import_module(package_name).__path__, package_name + '.'):
        # Determine the canonical flag name based on the module name.  The
        # module's base name (without package prefix) corresponds to the flag.
        module_name = name.split('.')[-1]
        try:
            # Lazy import to avoid circular imports.  Import here rather than
            # at module top level to ensure environment is fully configured.
            from backend.core.feature_flags import is_enabled  # type: ignore

            if not is_enabled(module_name):
                logger.info("Plugin %s is disabled via feature flag", name)
                continue
        except Exception as exc:
            logger.exception("Error checking feature flag for %s: %s", name, exc)
            # In case of any failure checking flags, proceed to import plugin

        try:
            module = importlib.import_module(name)
        except Exception as exc:
            logger.exception("Failed to import plugin module %s: %s", name, exc)
            continue

        register = getattr(module, 'register', None)
        if callable(register):
            try:
                register(app)
                logger.info("Registered plugin: %s", name)
            except Exception as exc:
                logger.exception("Failed to register plugin %s: %s", name, exc)
        else:
            logger.debug("No register function in plugin %s; skipping", name)