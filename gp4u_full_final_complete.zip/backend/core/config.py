"""
Application configuration management.

This module defines the BaseSettings subclass used to load configuration
from environment variables.  Settings include database URL, secret keys and
external service credentials (e.g. Stripe and SendGrid).  In production,
set these environment variables before starting the application.

Example:

    from backend.core.config import settings
    print(settings.database_url)

"""

from functools import lru_cache
from pydantic import BaseSettings, AnyUrl, SecretStr


class Settings(BaseSettings):
    """Global application settings."""

    app_name: str = "GP4U"
    secret_key: SecretStr
    database_url: AnyUrl
    redis_url: AnyUrl = "redis://localhost:6379/0"
    stripe_secret_key: SecretStr
    stripe_publishable_key: SecretStr
    sendgrid_api_key: SecretStr

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    """Return cached settings instance."""
    return Settings()


settings = get_settings()