"""
Application-specific exception classes.

This module defines a small hierarchy of exceptions that can be used
throughout the GP4U backend to represent common error conditions in
a structured way.  Each exception carries an HTTP status code and
message that can be returned to API clients via FastAPI's
``HTTPException``.  Raising these exceptions directly from services
allows handlers in the API layer to convert them to appropriate
responses without duplicating status codes and messages.

Example::

    from backend.core.exceptions import NotFoundError
    raise NotFoundError("GPU not found")
"""

from __future__ import annotations

from typing import Optional

from fastapi import HTTPException, status


class GP4UError(Exception):
    """Base class for GP4U-specific exceptions."""

    status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR
    detail: str = "Internal server error"

    def __init__(self, detail: Optional[str] = None) -> None:
        if detail:
            self.detail = detail
        super().__init__(self.detail)

    def to_http_exception(self) -> HTTPException:
        """Convert this error to a FastAPI ``HTTPException``."""
        return HTTPException(status_code=self.status_code, detail=self.detail)


class BadRequestError(GP4UError):
    """Raised when the client sends invalid input or request parameters."""

    status_code = status.HTTP_400_BAD_REQUEST
    detail = "Bad request"


class UnauthorizedError(GP4UError):
    """Raised when authentication or authorization fails."""

    status_code = status.HTTP_401_UNAUTHORIZED
    detail = "Unauthorized"


class ForbiddenError(GP4UError):
    """Raised when a user attempts an action they do not have permission for."""

    status_code = status.HTTP_403_FORBIDDEN
    detail = "Forbidden"


class NotFoundError(GP4UError):
    """Raised when a requested resource cannot be found."""

    status_code = status.HTTP_404_NOT_FOUND
    detail = "Resource not found"


class ConflictError(GP4UError):
    """Raised when a request would create a conflicting resource (e.g. duplicate)."""

    status_code = status.HTTP_409_CONFLICT
    detail = "Conflict"


class ValidationError(GP4UError):
    """Raised when model or business logic validation fails."""

    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    detail = "Validation error"