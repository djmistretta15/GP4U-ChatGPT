"""
Database configuration and session management.

Uses SQLAlchemy to create an Engine and a SessionLocal factory.  The
database URL is read from the Settings object defined in config.py.

Example:
    from backend.core.database import SessionLocal
    db = SessionLocal()
    try:
        # interact with database
        pass
    finally:
        db.close()
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from backend.core.config import settings


# Create SQLAlchemy engine
engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
)


# Base class for models
Base = declarative_base()
# Create a configured "Session" class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """Provide a transactional scope around a series of operations."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()