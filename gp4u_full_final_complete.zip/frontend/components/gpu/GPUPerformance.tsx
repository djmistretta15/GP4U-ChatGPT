import React from "react";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from "recharts";

interface GPUPerformanceProps {
  metrics: { metric: string; value: number }[];
}

/**
 * Displays a radar chart summarising GPU performance across several
 * dimensions (e.g. memory bandwidth, compute, latency). Sample data
 * should be provided via the ``metrics`` prop.
 */
export const GPUPerformance: React.FC<GPUPerformanceProps> = ({ metrics }) => {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={metrics}>
          <PolarGrid />
          <PolarAngleAxis dataKey="metric" />
          <PolarRadiusAxis angle={30} domain={[0, Math.max(...metrics.map(m => m.value)) || 1]} />
          <Radar name="GPU" dataKey="value" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.3} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};