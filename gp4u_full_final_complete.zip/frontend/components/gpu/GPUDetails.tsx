import React from "react";
import { GPU } from "../../hooks/useGPU";
import { formatCurrency } from "../../utils/formatting";

interface GPUDetailsProps {
  gpu: GPU | null;
}

/**
 * Detailed view of a GPU. Displays extended information and could be
 * expanded to include performance metrics, owner details, reviews, etc.
 */
export const GPUDetails: React.FC<GPUDetailsProps> = ({ gpu }) => {
  if (!gpu) return <p>Select a GPU to see details.</p>;
  return (
    <div className="border rounded p-4 space-y-2">
      <h3 className="text-xl font-semibold">{gpu.name}</h3>
      <p className="text-gray-600">Manufacturer: {gpu.manufacturer}</p>
      {gpu.memory_gb !== undefined && <p>Memory: {gpu.memory_gb} GB</p>}
      {gpu.price_per_hour !== undefined && (
        <p>Price per hour: {formatCurrency(gpu.price_per_hour)}</p>
      )}
      {gpu.performance_score !== undefined && <p>Performance score: {gpu.performance_score}</p>}
    </div>
  );
};