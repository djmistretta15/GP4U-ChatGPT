import React, { useState } from "react";
import api from "../../utils/api";

/**
 * Form to register a new GPU. Sends data to the backend to create a
 * GPU record. Currently uses minimal fields for demonstration.
 */
export const RegisterGPU: React.FC = () => {
  const [name, setName] = useState("");
  const [manufacturer, setManufacturer] = useState("");
  const [memory, setMemory] = useState<number | "">("");
  const [price, setPrice] = useState<number | "">("");
  const [message, setMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post("/gpus", {
        name,
        manufacturer,
        memory_gb: memory ? Number(memory) : undefined,
        price_per_hour: price ? Number(price) : undefined,
      });
      setMessage("GPU registered successfully!");
      setName("");
      setManufacturer("");
      setMemory("");
      setPrice("");
    } catch (err) {
      console.error(err);
      setMessage("Failed to register GPU");
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h3 className="text-xl font-semibold mb-2">Register a GPU</h3>
      {message && <p className="mb-2">{message}</p>}
      <form onSubmit={handleSubmit} className="space-y-2">
        <input
          type="text"
          placeholder="GPU name"
          value={name}
          onChange={e => setName(e.target.value)}
          className="border p-2 w-full"
          required
        />
        <input
          type="text"
          placeholder="Manufacturer"
          value={manufacturer}
          onChange={e => setManufacturer(e.target.value)}
          className="border p-2 w-full"
          required
        />
        <input
          type="number"
          placeholder="Memory (GB)"
          value={memory}
          onChange={e => setMemory(e.target.value === "" ? "" : Number(e.target.value))}
          className="border p-2 w-full"
        />
        <input
          type="number"
          placeholder="Price per hour"
          value={price}
          onChange={e => setPrice(e.target.value === "" ? "" : Number(e.target.value))}
          className="border p-2 w-full"
        />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2">
          Register GPU
        </button>
      </form>
    </div>
  );
};