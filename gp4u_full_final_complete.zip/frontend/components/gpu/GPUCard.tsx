import React from "react";
import { GPU } from "../../hooks/useGPU";
import { formatCurrency } from "../../utils/formatting";

interface GPUCardProps {
  gpu: GPU;
  onSelect?: (id: number) => void;
}

/**
 * Displays summary information about a GPU and optionally allows
 * selecting it. When ``onSelect`` is provided, a "Select" button will
 * appear; otherwise the card is non‑interactive.
 */
export const GPUCard: React.FC<GPUCardProps> = ({ gpu, onSelect }) => {
  return (
    <div className="border rounded p-4 flex flex-col space-y-2">
      <h3 className="font-semibold">{gpu.name}</h3>
      <p className="text-sm text-gray-600">{gpu.manufacturer}</p>
      {gpu.price_per_hour !== undefined && (
        <p className="text-sm">Price/hour: {formatCurrency(gpu.price_per_hour)}</p>
      )}
      {onSelect && (
        <button
          onClick={() => onSelect(gpu.id)}
          className="mt-auto bg-blue-500 text-white px-3 py-1 rounded"
        >
          Select
        </button>
      )}
    </div>
  );
};