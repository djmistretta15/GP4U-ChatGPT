import React from "react";
import { GPU } from "../../hooks/useGPU";
import { GPUCard } from "./GPUCard";

interface GPUListProps {
  gpus: GPU[];
  onSelect?: (id: number) => void;
}

/**
 * Renders a grid of GPUs. For each GPU a ``GPUCard`` is displayed. If
 * ``onSelect`` is provided the cards will include a button to select
 * that GPU.
 */
export const GPUList: React.FC<GPUListProps> = ({ gpus, onSelect }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {gpus.map(gpu => (
        <GPUCard key={gpu.id} gpu={gpu} onSelect={onSelect} />
      ))}
    </div>
  );
};