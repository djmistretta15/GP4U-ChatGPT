import React from "react";

/**
 * Placeholder component for a map. In a production system this would
 * integrate with Mapbox GL or another map provider to allow users to
 * visualise GPU locations. For now it renders a fixed container.
 */
export const LocationMap: React.FC = () => {
  return (
    <div className="bg-gray-200 h-64 flex items-center justify-center">
      <span className="text-gray-600">Map placeholder</span>
    </div>
  );
};