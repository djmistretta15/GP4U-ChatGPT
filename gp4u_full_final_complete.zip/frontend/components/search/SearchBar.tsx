import React, { useState } from "react";

interface SearchBarProps {
  onSearch: (query: string) => void;
}

/**
 * Text input for entering a search query. Calls the provided
 * ``onSearch`` callback when the form is submitted.
 */
export const SearchBar: React.FC<SearchBarProps> = ({ onSearch }) => {
  const [query, setQuery] = useState("");
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
  };
  return (
    <form onSubmit={handleSubmit} className="flex space-x-2">
      <input
        type="text"
        placeholder="Search GPUs"
        value={query}
        onChange={e => setQuery(e.target.value)}
        className="border p-2 flex-grow"
      />
      <button type="submit" className="bg-blue-500 text-white px-4 py-2">
        Search
      </button>
    </form>
  );
};