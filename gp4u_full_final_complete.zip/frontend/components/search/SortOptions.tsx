import React from "react";

interface SortOptionsProps {
  onSortChange: (sortBy: string) => void;
}

/**
 * Dropdown for selecting sort order. Provides options to sort by
 * price (ascending) or performance score (descending). Invokes
 * ``onSortChange`` with the selected value when changed.
 */
export const SortOptions: React.FC<SortOptionsProps> = ({ onSortChange }) => {
  return (
    <div className="mb-4">
      <label className="mr-2">Sort by:</label>
      <select
        onChange={e => onSortChange(e.target.value)}
        className="border p-1"
        defaultValue=""
      >
        <option value="">-- select --</option>
        <option value="price_asc">Price (Low to High)</option>
        <option value="price_desc">Price (High to Low)</option>
        <option value="performance_desc">Performance (High to Low)</option>
      </select>
    </div>
  );
};