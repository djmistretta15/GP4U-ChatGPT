import React, { useState } from "react";

interface FilterPanelProps {
  onFilterChange: (filters: Record<string, string>) => void;
}

/**
 * Panel for selecting search filters such as manufacturer. When a
 * filter is changed the ``onFilterChange`` callback is invoked with
 * the updated filter state.
 */
export const FilterPanel: React.FC<FilterPanelProps> = ({ onFilterChange }) => {
  const [manufacturer, setManufacturer] = useState("");

  const handleApply = () => {
    const filters: Record<string, string> = {};
    if (manufacturer) filters["manufacturer"] = manufacturer;
    onFilterChange(filters);
  };

  return (
    <div className="border p-4 mb-4">
      <h4 className="font-semibold mb-2">Filters</h4>
      <label className="block mb-2">
        Manufacturer:
        <input
          type="text"
          value={manufacturer}
          onChange={e => setManufacturer(e.target.value)}
          className="border p-1 w-full"
        />
      </label>
      <button onClick={handleApply} className="bg-blue-500 text-white px-3 py-1">
        Apply
      </button>
    </div>
  );
};