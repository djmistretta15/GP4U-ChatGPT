import { useState } from "react";
import api from "@/utils/api";

interface GPUResult {
  id: number;
  name: string;
  manufacturer: string;
  memory_gb: number;
  price_per_hour: number;
}

/**
 * AdvancedSearchForm component.
 *
 * Provides an interface to perform advanced GPU searches with
 * optional filters for memory and price.  Results are displayed
 * below the form.  In a full implementation you might add
 * pagination and sorting.
 */
export default function AdvancedSearchForm() {
  const [query, setQuery] = useState<string>("");
  const [minMemory, setMinMemory] = useState<number | "">("");
  const [maxMemory, setMaxMemory] = useState<number | "">("");
  const [minPrice, setMinPrice] = useState<number | "">("");
  const [maxPrice, setMaxPrice] = useState<number | "">("");
  const [results, setResults] = useState<GPUResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResults([]);
    try {
      const params: any = {};
      if (query) params.q = query;
      if (minMemory !== "") params.min_memory = minMemory;
      if (maxMemory !== "") params.max_memory = maxMemory;
      if (minPrice !== "") params.min_price = minPrice;
      if (maxPrice !== "") params.max_price = maxPrice;
      const response = await api.get("/search/gpus/advanced", { params });
      setResults(response.data);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Search failed");
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm">
      <h2 className="text-xl font-semibold mb-2">Advanced GPU Search</h2>
      <form onSubmit={handleSearch} className="grid grid-cols-2 gap-2 mb-4">
        <input
          type="text"
          className="border rounded p-2 col-span-2"
          placeholder="Name or manufacturer"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <input
          type="number"
          className="border rounded p-2"
          placeholder="Min memory (GB)"
          value={minMemory}
          onChange={(e) => setMinMemory(e.target.value === "" ? "" : Number(e.target.value))}
        />
        <input
          type="number"
          className="border rounded p-2"
          placeholder="Max memory (GB)"
          value={maxMemory}
          onChange={(e) => setMaxMemory(e.target.value === "" ? "" : Number(e.target.value))}
        />
        <input
          type="number"
          className="border rounded p-2"
          step="0.01"
          placeholder="Min price per hour"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value === "" ? "" : Number(e.target.value))}
        />
        <input
          type="number"
          className="border rounded p-2"
          step="0.01"
          placeholder="Max price per hour"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value === "" ? "" : Number(e.target.value))}
        />
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded col-span-2 hover:bg-blue-700"
        >
          Search
        </button>
      </form>
      {error && <p className="text-red-600 mb-2">{error}</p>}
      {results.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto">
            <thead className="bg-gray-200">
              <tr>
                <th className="px-4 py-2 text-left">ID</th>
                <th className="px-4 py-2 text-left">Name</th>
                <th className="px-4 py-2 text-left">Manufacturer</th>
                <th className="px-4 py-2 text-left">Memory (GB)</th>
                <th className="px-4 py-2 text-left">Price/hr</th>
              </tr>
            </thead>
            <tbody>
              {results.map((gpu) => (
                <tr key={gpu.id} className="border-b">
                  <td className="px-4 py-1">{gpu.id}</td>
                  <td className="px-4 py-1">{gpu.name}</td>
                  <td className="px-4 py-1">{gpu.manufacturer}</td>
                  <td className="px-4 py-1">{gpu.memory_gb}</td>
                  <td className="px-4 py-1">${gpu.price_per_hour.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}