import React from "react";
import { useAuth } from "../../hooks/useAuth";
import { Link } from "react-router-dom";

/**
 * Header with simple navigation and authentication controls.
 */
export const Header: React.FC = () => {
  const { user, logout } = useAuth();
  return (
    <header className="bg-gray-800 text-white p-4 flex justify-between items-center">
      <div className="flex items-center space-x-4">
        <Link to="/" className="font-bold text-xl">
          GP4U
        </Link>
        <Link to="/search" className="hover:underline">
          Search
        </Link>
        {user && (
          <Link to="/dashboard" className="hover:underline">
            Dashboard
          </Link>
        )}
      </div>
      <div>
        {user ? (
          <button onClick={logout} className="bg-red-500 px-3 py-1 rounded">
            Logout
          </button>
        ) : (
          <Link to="/login" className="bg-blue-500 px-3 py-1 rounded">
            Login
          </Link>
        )}
      </div>
    </header>
  );
};