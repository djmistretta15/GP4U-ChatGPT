import { useState } from "react";
import api from "@/utils/api";

/**
 * ChatbotAssistant component.
 *
 * Provides a simple UI for users to ask a question about their workload and
 * receive a GPU recommendation from the backend. This component uses the
 * ``/chatbot`` endpoint provided by the AI assistant plugin to perform the
 * recommendation. It is intentionally minimal; production implementations
 * should add error handling, loading states and UI styling.
 */
export default function ChatbotAssistant() {
  const [prompt, setPrompt] = useState("");
  const [recommendation, setRecommendation] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setRecommendation(null);
    if (!prompt.trim()) return;
    try {
      const response = await api.post("/chatbot", { prompt });
      setRecommendation(response.data.recommended_gpu);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to fetch recommendation");
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm">
      <h2 className="text-xl font-semibold mb-2">AI GPU Assistant</h2>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
        <textarea
          className="border rounded p-2"
          placeholder="Describe your workload (e.g., train an AI model, render a video)"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={3}
        />
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Ask Assistant
        </button>
      </form>
      {error && <p className="text-red-600 mt-2">{error}</p>}
      {recommendation && (
        <div className="mt-4 p-2 bg-gray-100 rounded">
          <h3 className="font-semibold">Recommended GPU</h3>
          <p>Name: {recommendation.name}</p>
          <p>Manufacturer: {recommendation.manufacturer}</p>
          <p>Memory (GB): {recommendation.memory_gb}</p>
          <p>Price/hour: ${recommendation.price_per_hour.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}