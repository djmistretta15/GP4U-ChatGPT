import React, { useContext } from "react";
import { LocalizationContext } from "../../contexts/LocalizationContext";

/**
 * Language selector component.
 *
 * Renders a dropdown allowing the user to choose their preferred language.
 * It consumes the localisation context to read the current language and
 * available options.  When the selection changes, ``setLanguage`` is
 * invoked to update the context and trigger reloading of translations.
 */
const LanguageSelector: React.FC = () => {
  const context = useContext(LocalizationContext);
  if (!context) {
    return null;
  }
  const { language, availableLanguages, setLanguage } = context;
  return (
    <select
      className="border rounded p-1"
      value={language}
      onChange={(e) => setLanguage(e.target.value)}
    >
      {availableLanguages.map((lang) => (
        <option key={lang} value={lang}>
          {lang.toUpperCase()}
        </option>
      ))}
    </select>
  );
};

export default LanguageSelector;