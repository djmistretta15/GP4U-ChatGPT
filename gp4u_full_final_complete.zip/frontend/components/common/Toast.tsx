import React from "react";

interface ToastProps {
  message: string;
  type?: "success" | "error" | "info";
  onClose?: () => void;
}

/**
 * Simple toast component to display transient messages. The toast
 * colour is determined by the ``type`` prop. If ``onClose`` is
 * provided a close button will be rendered.
 */
export const Toast: React.FC<ToastProps> = ({ message, type = "info", onClose }) => {
  let bgColour = "bg-blue-500";
  if (type === "success") bgColour = "bg-green-500";
  if (type === "error") bgColour = "bg-red-500";
  return (
    <div className={`text-white px-4 py-2 rounded shadow ${bgColour} flex justify-between items-center`}>
      <span>{message}</span>
      {onClose && (
        <button onClick={onClose} className="ml-4 font-bold">
          ×
        </button>
      )}
    </div>
  );
};