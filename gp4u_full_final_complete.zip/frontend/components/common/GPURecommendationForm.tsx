import { useState } from "react";
import api from "@/utils/api";

/**
 * GPURecommendationForm component.
 *
 * Provides a form for users to describe their workload and retrieve a
 * GPU recommendation via the ``/recommendations`` endpoint.  This
 * component demonstrates how to consume the recommendation plugin
 * asynchronously.  In a full application you might provide richer
 * suggestions and handle streaming responses.
 */
export default function GPURecommendationForm() {
  const [prompt, setPrompt] = useState("");
  const [recommendation, setRecommendation] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setRecommendation(null);
    if (!prompt.trim()) return;
    try {
      const response = await api.post("/recommendations", { prompt });
      setRecommendation(response.data.recommended_gpu);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to fetch recommendation");
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm max-w-md">
      <h2 className="text-xl font-semibold mb-2">GPU Recommendation</h2>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
        <textarea
          className="border rounded p-2"
          placeholder="Describe your workload (e.g., train a model, render a video, mine crypto)"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={3}
        />
        <button
          type="submit"
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          Get Recommendation
        </button>
      </form>
      {error && <p className="text-red-600 mt-2">{error}</p>}
      {recommendation && (
        <div className="mt-4 p-2 bg-gray-100 rounded">
          <h3 className="font-semibold">Recommended GPU</h3>
          <p>Name: {recommendation.name}</p>
          <p>Manufacturer: {recommendation.manufacturer}</p>
          <p>Memory (GB): {recommendation.memory_gb}</p>
          <p>Price/hour: ${recommendation.price_per_hour.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}