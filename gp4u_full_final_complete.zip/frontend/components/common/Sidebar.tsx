import React from "react";
import { Link } from "react-router-dom";

interface SidebarProps {
  items: { label: string; path: string }[];
}

/**
 * Sidebar navigation component. Takes an array of items with labels
 * and paths and renders a vertical navigation list. Could be extended
 * with active state and icons.
 */
export const Sidebar: React.FC<SidebarProps> = ({ items }) => {
  return (
    <nav className="w-48 bg-gray-100 p-4 border-r">
      <ul className="space-y-2">
        {items.map(item => (
          <li key={item.path}>
            <Link to={item.path} className="text-gray-700 hover:underline">
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
};