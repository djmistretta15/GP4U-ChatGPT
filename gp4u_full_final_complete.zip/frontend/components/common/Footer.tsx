import React from "react";

/** Simple footer component with copyright notice. */
export const Footer: React.FC = () => {
  return (
    <footer className="mt-8 text-center text-sm text-gray-500">
      &copy; {new Date().getFullYear()} GP4U. All rights reserved.
    </footer>
  );
};