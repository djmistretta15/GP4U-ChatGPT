import { useState } from "react";
import api from "@/utils/api";

/**
 * PriceSuggestionForm component.
 *
 * Provides a form for owners or administrators to request a suggested
 * rental price for a given GPU.  Users enter the GPU name and current
 * supply/demand metrics.  Upon submission, the form calls the
 * ``/pricing`` endpoint exposed by the pricing engine plugin and
 * displays the recommended hourly price.
 */
export default function PriceSuggestionForm() {
  const [name, setName] = useState("");
  const [supply, setSupply] = useState<number>(1);
  const [demand, setDemand] = useState<number>(1);
  const [suggestedPrice, setSuggestedPrice] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuggestedPrice(null);
    if (!name.trim()) {
      setError("Please enter a GPU name");
      return;
    }
    try {
      const response = await api.post("/pricing", {
        name,
        supply,
        demand,
      });
      setSuggestedPrice(response.data.suggested_price);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to fetch price suggestion");
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm max-w-md">
      <h2 className="text-xl font-semibold mb-2">Suggest Rental Price</h2>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
        <input
          type="text"
          className="border rounded p-2"
          placeholder="GPU name (e.g., A100)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <div className="flex space-x-2">
          <input
            type="number"
            className="border rounded p-2 w-1/2"
            min={1}
            placeholder="Supply"
            value={supply}
            onChange={(e) => setSupply(Number(e.target.value))}
          />
          <input
            type="number"
            className="border rounded p-2 w-1/2"
            min={0}
            placeholder="Demand"
            value={demand}
            onChange={(e) => setDemand(Number(e.target.value))}
          />
        </div>
        <button
          type="submit"
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
        >
          Get Suggestion
        </button>
      </form>
      {error && <p className="text-red-600 mt-2">{error}</p>}
      {suggestedPrice !== null && (
        <div className="mt-4 p-2 bg-gray-100 rounded">
          <h3 className="font-semibold">Suggested Price per Hour</h3>
          <p>${suggestedPrice.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}