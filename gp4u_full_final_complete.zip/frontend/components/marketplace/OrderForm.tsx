import { useState } from "react";
import api from "@/utils/api";

/**
 * OrderForm component.
 *
 * Allows renters to create a new marketplace order.  The form collects
 * the GPU ID, quantity and the price per hour the renter is willing
 * to pay.  User ID is currently provided manually; in a real
 * application this would come from the authenticated session.
 */
export default function OrderForm() {
  const [gpuId, setGpuId] = useState<number>(0);
  const [userId, setUserId] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);
  const [price, setPrice] = useState<number>(1);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    try {
      const response = await api.post("/marketplace/orders", {
        gpu_id: gpuId,
        user_id: userId,
        quantity,
        price_per_hour: price,
      });
      setSuccess(`Order ${response.data.id} created successfully`);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to create order");
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm max-w-md">
      <h2 className="text-xl font-semibold mb-2">Place a Marketplace Order</h2>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
        <input
          type="number"
          className="border rounded p-2"
          placeholder="GPU ID"
          value={gpuId}
          onChange={(e) => setGpuId(Number(e.target.value))}
        />
        <input
          type="number"
          className="border rounded p-2"
          placeholder="User ID"
          value={userId}
          onChange={(e) => setUserId(Number(e.target.value))}
        />
        <input
          type="number"
          className="border rounded p-2"
          min={1}
          placeholder="Quantity"
          value={quantity}
          onChange={(e) => setQuantity(Number(e.target.value))}
        />
        <input
          type="number"
          className="border rounded p-2"
          min={0}
          step="0.01"
          placeholder="Price per hour"
          value={price}
          onChange={(e) => setPrice(Number(e.target.value))}
        />
        <button
          type="submit"
          className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
        >
          Submit Order
        </button>
      </form>
      {error && <p className="text-red-600 mt-2">{error}</p>}
      {success && <p className="text-green-600 mt-2">{success}</p>}
    </div>
  );
}