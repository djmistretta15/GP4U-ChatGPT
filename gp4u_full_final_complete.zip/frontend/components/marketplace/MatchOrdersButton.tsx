import { useState } from "react";
import api from "@/utils/api";

/**
 * MatchOrdersButton component.
 *
 * Provides a button that triggers the order matching process on the
 * server.  Displays the IDs of matched orders upon completion.  In a
 * production interface you might disable the button during
 * processing and show a loading spinner.
 */
export default function MatchOrdersButton() {
  const [matchedIds, setMatchedIds] = useState<number[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const handleMatch = async () => {
    setLoading(true);
    setError(null);
    setMatchedIds(null);
    try {
      const response = await api.post("/marketplace/match");
      setMatchedIds(response.data.matched_order_ids);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to match orders");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm max-w-md">
      <button
        onClick={handleMatch}
        className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
        disabled={loading}
      >
        {loading ? "Matching…" : "Run Matching"}
      </button>
      {error && <p className="text-red-600 mt-2">{error}</p>}
      {matchedIds && (
        <div className="mt-2">
          <p className="font-semibold">Matched Orders:</p>
          {matchedIds.length > 0 ? (
            <ul className="list-disc list-inside">
              {matchedIds.map((id) => (
                <li key={id}>Order {id}</li>
              ))}
            </ul>
          ) : (
            <p>No orders were matched.</p>
          )}
        </div>
      )}
    </div>
  );
}