import { useEffect, useState } from "react";
import api from "@/utils/api";

interface Order {
  id: number;
  gpu_id: number;
  user_id: number;
  quantity: number;
  price_per_hour: number;
  status: string;
}

/**
 * OrderList component.
 *
 * Fetches all marketplace orders from the backend and displays them in
 * a table.  In a real application this list might be filtered by
 * user or status, and pagination would be needed for large datasets.
 */
export default function OrderList() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await api.get("/marketplace/orders");
        setOrders(response.data);
      } catch (err: any) {
        setError(err?.response?.data?.detail || "Failed to fetch orders");
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  return (
    <div className="p-4 bg-white rounded shadow-sm">
      <h2 className="text-xl font-semibold mb-2">Marketplace Orders</h2>
      {loading && <p>Loading…</p>}
      {error && <p className="text-red-600">{error}</p>}
      {!loading && orders.length === 0 && <p>No orders found.</p>}
      {orders.length > 0 && (
        <table className="min-w-full table-auto">
          <thead>
            <tr className="bg-gray-200">
              <th className="px-4 py-2 text-left">ID</th>
              <th className="px-4 py-2 text-left">GPU ID</th>
              <th className="px-4 py-2 text-left">User ID</th>
              <th className="px-4 py-2 text-left">Qty</th>
              <th className="px-4 py-2 text-left">Price/hr</th>
              <th className="px-4 py-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b">
                <td className="px-4 py-1">{order.id}</td>
                <td className="px-4 py-1">{order.gpu_id}</td>
                <td className="px-4 py-1">{order.user_id}</td>
                <td className="px-4 py-1">{order.quantity}</td>
                <td className="px-4 py-1">
                  ${order.price_per_hour.toFixed(2)}
                </td>
                <td className="px-4 py-1 capitalize">{order.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}