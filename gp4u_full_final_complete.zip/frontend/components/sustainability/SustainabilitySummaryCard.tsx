import React, { useEffect, useState } from "react";
import api from "../../utils/api";

interface SummaryMetrics {
  total_power_watts: number;
  total_energy_kwh_per_hour: number;
  total_carbon_kg_per_hour: number;
  total_offset_cost_per_hour: number;
}

/**
 * Display aggregated sustainability metrics for the platform.
 *
 * This component fetches summary metrics from the backend and shows
 * total power draw, energy consumption, carbon emissions and offset costs.
 */
const SustainabilitySummaryCard: React.FC = () => {
  const [metrics, setMetrics] = useState<SummaryMetrics | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSummary = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await api.get("/sustainability/summary");
        setMetrics(response.data);
      } catch (err: any) {
        setError(err?.response?.data?.detail || "Failed to load metrics");
      } finally {
        setLoading(false);
      }
    };
    fetchSummary();
  }, []);

  if (loading) {
    return <div>Loading sustainability metrics…</div>;
  }
  if (error) {
    return <div className="text-red-500">{error}</div>;
  }
  if (!metrics) {
    return null;
  }
  return (
    <div className="bg-white shadow-md rounded-lg p-4 mb-4">
      <h2 className="text-lg font-semibold mb-2">Sustainability Overview</h2>
      <p>Total Power Draw: {metrics.total_power_watts.toFixed(2)} W</p>
      <p>Energy Consumption: {metrics.total_energy_kwh_per_hour.toFixed(3)} kWh/h</p>
      <p>Carbon Emissions: {metrics.total_carbon_kg_per_hour.toFixed(3)} kg CO₂/h</p>
      <p>Offset Cost: ${metrics.total_offset_cost_per_hour.toFixed(2)} per h</p>
    </div>
  );
};

export default SustainabilitySummaryCard;