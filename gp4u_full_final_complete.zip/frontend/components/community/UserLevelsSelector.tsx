import { useState } from "react";
import api from "@/utils/api";

/**
 * UserLevelsSelector component.
 *
 * This component allows the user to choose an experience level
 * (beginner, intermediate, expert) and fetches the corresponding
 * feature recommendations from the backend via the user‑levels plugin.
 * The recommendations are displayed as a simple list.
 */
export default function UserLevelsSelector() {
  const [level, setLevel] = useState<string>("beginner");
  const [features, setFeatures] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchFeatures = async () => {
    setError(null);
    setFeatures(null);
    try {
      const response = await api.get(`/user-levels/${level}`);
      setFeatures(response.data.features);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to fetch features");
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow-sm max-w-md">
      <h2 className="text-xl font-semibold mb-2">Choose Your Experience Level</h2>
      <div className="flex items-center space-x-2 mb-4">
        <label htmlFor="level-select" className="text-sm font-medium">
          Level:
        </label>
        <select
          id="level-select"
          className="border rounded p-1"
          value={level}
          onChange={(e) => setLevel(e.target.value)}
        >
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="expert">Expert</option>
        </select>
        <button
          onClick={fetchFeatures}
          className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
        >
          Get Features
        </button>
      </div>
      {error && <p className="text-red-600 mb-2">{error}</p>}
      {features && (
        <div>
          <h3 className="font-semibold mb-1">Recommended Features:</h3>
          <ul className="list-disc list-inside space-y-1">
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}