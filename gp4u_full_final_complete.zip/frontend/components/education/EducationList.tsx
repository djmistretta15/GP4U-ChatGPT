import React, { useEffect, useState } from "react";
import api from "../../utils/api";

interface ResourceSummary {
  topic: string;
  title: string;
  description: string;
}

interface ResourceDetail extends ResourceSummary {
  url?: string;
}

/**
 * Lists educational resources and allows viewing details.
 */
const EducationList: React.FC = () => {
  const [resources, setResources] = useState<ResourceSummary[]>([]);
  const [selected, setSelected] = useState<ResourceDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchResources = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await api.get("/education/resources");
        setResources(response.data);
      } catch (err: any) {
        setError(err?.response?.data?.detail || "Failed to load resources");
      } finally {
        setLoading(false);
      }
    };
    fetchResources();
  }, []);

  const handleSelect = async (topic: string) => {
    setLoading(true);
    setError(null);
    try {
      const response = await api.get(`/education/${topic}`);
      setSelected(response.data);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to load resource");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4">
      <h2 className="text-lg font-semibold mb-2">Educational Resources</h2>
      {loading && <p>Loading…</p>}
      {error && <p className="text-red-500">{error}</p>}
      {!loading && !error && (
        <div className="flex flex-col sm:flex-row gap-4">
          <ul className="flex-1 list-disc list-inside">
            {resources.map((res) => (
              <li key={res.topic} className="cursor-pointer text-blue-600" onClick={() => handleSelect(res.topic)}>
                <span className="font-semibold">{res.title}:</span> {res.description}
              </li>
            ))}
          </ul>
          {selected && (
            <div className="flex-1">
              <h3 className="font-semibold mb-1">{selected.title}</h3>
              <p className="mb-2">{selected.description}</p>
              {selected.url && (
                <a href={selected.url} target="_blank" rel="noopener noreferrer" className="text-blue-500 underline">
                  Learn more
                </a>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default EducationList;