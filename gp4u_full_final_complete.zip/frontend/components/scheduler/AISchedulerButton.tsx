import React, { useState } from "react";
import api from "../../utils/api";

/**
 * Button that triggers the AI scheduler to run and displays results.
 */
const AISchedulerButton: React.FC = () => {
  const [assignments, setAssignments] = useState<{ job_id: number; gpu_id: number }[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleRunScheduler = async () => {
    setLoading(true);
    setError(null);
    setAssignments([]);
    try {
      const response = await api.post("/scheduler/ai/run");
      setAssignments(response.data);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to run scheduler");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4">
      <h2 className="text-lg font-semibold mb-2">AI Scheduler</h2>
      <button
        onClick={handleRunScheduler}
        className="bg-blue-500 text-white px-4 py-2 rounded mb-2"
        disabled={loading}
      >
        {loading ? "Running…" : "Run AI Scheduler"}
      </button>
      {error && <p className="text-red-500">{error}</p>}
      {assignments.length > 0 && (
        <div className="text-sm">
          <p className="font-semibold mb-1">Assignments:</p>
          <ul className="list-disc list-inside">
            {assignments.map((a, index) => (
              <li key={index}>
                Job {a.job_id} → GPU {a.gpu_id}
              </li>
            ))}
          </ul>
        </div>
      )}
      {assignments.length === 0 && !loading && !error && (
        <p>No assignments created.</p>
      )}
    </div>
  );
};

export default AISchedulerButton;