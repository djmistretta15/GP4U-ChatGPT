import React from "react";

/**
 * Page displayed after a user requests verification. In a full
 * implementation this component would read the token from the URL
 * query parameters and call the backend to verify the user's email.
 * Currently it just informs the user to check their inbox.
 */
export const EmailVerification: React.FC = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-2">Verify Your Email</h2>
      <p>
        We have sent you a verification link. Please check your email and
        click the link to activate your account.
      </p>
    </div>
  );
};