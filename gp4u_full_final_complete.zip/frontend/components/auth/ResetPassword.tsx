import React, { useState } from "react";
import api from "../../utils/api";

/**
 * Password reset form. In a real application the token would be
 * extracted from the URL and submitted along with the new password
 * to the backend. Here we simply send the new password and display
 * confirmation.
 */
export const ResetPassword: React.FC = () => {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [reset, setReset] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      alert("Passwords do not match");
      return;
    }
    try {
      await api.post("/auth/reset-password", { password });
      setReset(true);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-4">Reset Password</h2>
      {reset ? (
        <p>Your password has been reset. You may now log in with your new password.</p>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-2">
          <input
            type="password"
            placeholder="New password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="border p-2 w-full"
            required
          />
          <input
            type="password"
            placeholder="Confirm password"
            value={confirm}
            onChange={e => setConfirm(e.target.value)}
            className="border p-2 w-full"
            required
          />
          <button type="submit" className="bg-blue-500 text-white px-4 py-2">
            Reset Password
          </button>
        </form>
      )}
    </div>
  );
};