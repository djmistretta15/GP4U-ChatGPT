import React, { useState } from "react";
import { isValidEmail } from "../../utils/validation";
import api from "../../utils/api";

/**
 * Form to request a password reset email. The backend should implement
 * an endpoint to send a reset token. Here we call a placeholder
 * endpoint and display a confirmation message.
 */
export const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState("{}");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidEmail(email)) {
      alert("Please enter a valid email address");
      return;
    }
    try {
      await api.post("/auth/forgot-password", { email });
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitted(true);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-4">Forgot Password</h2>
      {submitted ? (
        <p>If an account exists for {email}, a reset link has been sent.</p>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-2">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            className="border p-2 w-full"
          />
          <button type="submit" className="bg-blue-500 text-white px-4 py-2">
            Send Reset Link
          </button>
        </form>
      )}
    </div>
  );
};