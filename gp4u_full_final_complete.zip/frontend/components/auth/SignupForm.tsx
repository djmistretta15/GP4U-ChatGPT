import React, { useState } from "react";
import { useAuth } from "../../hooks/useAuth";
import { isValidEmail, isStrongPassword } from "../../utils/validation";

/**
 * Sign up form component. Uses ``useAuth`` hook to register a new
 * account. Displays simple validation messages for email and password
 * strength.
 */
export const SignupForm: React.FC = () => {
  const { signup, loading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidEmail(email)) {
      setError("Invalid email address");
      return;
    }
    if (!isStrongPassword(password)) {
      setError("Password must be at least 8 characters");
      return;
    }
    setError(null);
    await signup({ email, password });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
        className="border p-2 w-full"
        required
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
        className="border p-2 w-full"
        required
      />
      {error && <div className="text-red-600 text-sm">{error}</div>}
      <button
        type="submit"
        disabled={loading}
        className="bg-green-500 text-white px-4 py-2 disabled:opacity-50"
      >
        {loading ? "Signing up..." : "Sign Up"}
      </button>
    </form>
  );
};