import React from "react";
import { OAUTH_PROVIDERS } from "../../utils/constants";
import api from "../../utils/api";

/**
 * Buttons to initiate OAuth logins. When clicked, requests the
 * authorization URL from the backend and then redirects the browser
 * to that URL. The list of providers is defined in ``constants.ts``.
 */
export const OAuthButtons: React.FC = () => {
  const handleOAuth = async (provider: string) => {
    try {
      const res = await api.get(`/auth/oauth/${provider}`);
      const { url } = res.data;
      window.location.href = url;
    } catch (err) {
      console.error(err);
    }
  };
  return (
    <div className="space-x-2 mt-4">
      {OAUTH_PROVIDERS.map(provider => (
        <button
          key={provider}
          onClick={() => handleOAuth(provider)}
          className="bg-gray-800 text-white px-3 py-2 rounded"
        >
          Login with {provider.charAt(0).toUpperCase() + provider.slice(1)}
        </button>
      ))}
    </div>
  );
};