import React from "react";
import { GPUManagement } from "./GPUManagement";
import { EarningsOverview } from "./EarningsOverview";
import { PayoutSettings } from "./PayoutSettings";

/**
 * Dashboard for GPU owners. Provides an overview of earnings and
 * registered GPUs as well as payout configuration.
 */
export const OwnerDashboard: React.FC = () => {
  return (
    <div className="p-4 space-y-4">
      <h2 className="text-2xl font-semibold">Owner Dashboard</h2>
      <EarningsOverview />
      <GPUManagement />
      <PayoutSettings />
    </div>
  );
};