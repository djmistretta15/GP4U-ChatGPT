import React, { useState } from "react";
import api from "../../utils/api";

/**
 * Form to configure payout settings. Allows the owner to set a payout
 * account and request a payout. Calls a placeholder endpoint on
 * submit and displays confirmation.
 */
export const PayoutSettings: React.FC = () => {
  const [account, setAccount] = useState("");
  const [amount, setAmount] = useState<number | "">("");
  const [message, setMessage] = useState<string | null>(null);

  const handlePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post("/payouts", { account, amount });
      setMessage("Payout requested successfully");
      setAccount("");
      setAmount("");
    } catch (err) {
      console.error(err);
      setMessage("Failed to request payout");
    }
  };

  return (
    <div className="p-4 max-w-md">
      <h3 className="text-lg font-semibold mb-2">Payout Settings</h3>
      {message && <p className="mb-2">{message}</p>}
      <form onSubmit={handlePayout} className="space-y-2">
        <input
          type="text"
          placeholder="Bank account or Stripe ID"
          value={account}
          onChange={e => setAccount(e.target.value)}
          className="border p-2 w-full"
          required
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={e => setAmount(e.target.value === "" ? "" : Number(e.target.value))}
          className="border p-2 w-full"
          required
        />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2">
          Request Payout
        </button>
      </form>
    </div>
  );
};