import React from "react";
import { EarningsChart } from "../dashboard/EarningsChart";

/**
 * Component that reuses the earnings chart for owners. Could be
 * expanded to filter by GPU or time range.
 */
export const EarningsOverview: React.FC = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Your Earnings</h3>
      <EarningsChart />
    </div>
  );
};