import React, { useEffect, useState } from "react";
import { GPU } from "../../hooks/useGPU";
import api from "../../utils/api";
import { GPUCard } from "../gpu/GPUCard";

/**
 * Manage the GPUs owned by the current user. Allows viewing and
 * potentially editing or deleting GPUs. For simplicity this just
 * fetches all GPUs and displays them.
 */
export const GPUManagement: React.FC = () => {
  const [gpus, setGpus] = useState<GPU[]>([]);
  useEffect(() => {
    async function fetch() {
      const res = await api.get("/gpus");
      setGpus(res.data);
    }
    fetch();
  }, []);
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Manage Your GPUs</h3>
      {gpus.length === 0 && <p>You have not registered any GPUs.</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {gpus.map(gpu => (
          <GPUCard key={gpu.id} gpu={gpu} />
        ))}
      </div>
    </div>
  );
};