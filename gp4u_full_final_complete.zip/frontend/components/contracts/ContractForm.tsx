import React, { useState } from "react";
import api from "../../utils/api";

interface Props {
  onCreated: () => void;
}

/**
 * A form for creating new contracts.  Accepts user ID, GPU ID,
 * contract type and duration, then posts to the backend.  On
 * success the caller's `onCreated` callback is triggered.
 */
const ContractForm: React.FC<Props> = ({ onCreated }) => {
  const [userId, setUserId] = useState<string>("");
  const [gpuId, setGpuId] = useState<string>("");
  const [contractType, setContractType] = useState<string>("fixed");
  const [duration, setDuration] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await api.post("/contracts/", {
        user_id: parseInt(userId, 10),
        gpu_id: parseInt(gpuId, 10),
        contract_type: contractType,
        duration_hours: duration,
      });
      // Clear form on success
      setUserId("");
      setGpuId("");
      setDuration(1);
      setContractType("fixed");
      onCreated();
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to create contract");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-lg p-4 mb-4">
      <h2 className="text-lg font-semibold mb-2">Create Contract</h2>
      <div className="flex flex-col sm:flex-row gap-2 mb-2">
        <input
          type="number"
          placeholder="User ID"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          className="border p-2 rounded flex-1"
          required
        />
        <input
          type="number"
          placeholder="GPU ID"
          value={gpuId}
          onChange={(e) => setGpuId(e.target.value)}
          className="border p-2 rounded flex-1"
          required
        />
        <select
          value={contractType}
          onChange={(e) => setContractType(e.target.value)}
          className="border p-2 rounded"
        >
          <option value="fixed">Fixed</option>
          <option value="spot">Spot</option>
        </select>
        <input
          type="number"
          min="1"
          value={duration}
          onChange={(e) => setDuration(parseInt(e.target.value, 10))}
          className="border p-2 rounded w-24"
        />
        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded"
          disabled={loading}
        >
          {loading ? "Creating…" : "Create"}
        </button>
      </div>
      {error && <p className="text-red-500 text-sm">{error}</p>}
    </form>
  );
};

export default ContractForm;