import React, { useEffect, useState } from "react";
import api from "../../utils/api";

interface Contract {
  id: number;
  user_id: number;
  gpu_id: number;
  contract_type: string;
  price_per_hour: number;
  start_time: string;
  end_time: string | null;
  status: string;
}

interface Props {
  userId: number;
}

/**
 * List contracts for the given user ID.
 */
const ContractList: React.FC<Props> = ({ userId }) => {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchContracts = async () => {
      if (!userId) return;
      setLoading(true);
      setError(null);
      try {
        const response = await api.get(`/contracts/${userId}`);
        setContracts(response.data);
      } catch (err: any) {
        setError(err?.response?.data?.detail || "Failed to load contracts");
      } finally {
        setLoading(false);
      }
    };
    fetchContracts();
  }, [userId]);

  if (!userId) {
    return null;
  }
  return (
    <div className="bg-white shadow-md rounded-lg p-4">
      <h2 className="text-lg font-semibold mb-2">Contracts for User {userId}</h2>
      {loading && <p>Loading contracts…</p>}
      {error && <p className="text-red-500">{error}</p>}
      {!loading && !error && contracts.length === 0 && <p>No contracts found.</p>}
      {!loading && !error && contracts.length > 0 && (
        <table className="min-w-full text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-2 py-1 text-left">ID</th>
              <th className="px-2 py-1 text-left">GPU ID</th>
              <th className="px-2 py-1 text-left">Type</th>
              <th className="px-2 py-1 text-left">Price/h</th>
              <th className="px-2 py-1 text-left">Start</th>
              <th className="px-2 py-1 text-left">End</th>
              <th className="px-2 py-1 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {contracts.map((c) => (
              <tr key={c.id} className="border-b">
                <td className="px-2 py-1">{c.id}</td>
                <td className="px-2 py-1">{c.gpu_id}</td>
                <td className="px-2 py-1 capitalize">{c.contract_type}</td>
                <td className="px-2 py-1">${c.price_per_hour.toFixed(2)}</td>
                <td className="px-2 py-1">{new Date(c.start_time).toLocaleString()}</td>
                <td className="px-2 py-1">
                  {c.end_time ? new Date(c.end_time).toLocaleString() : "--"}
                </td>
                <td className="px-2 py-1 capitalize">{c.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ContractList;