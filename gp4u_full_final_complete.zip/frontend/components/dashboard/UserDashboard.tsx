import React, { useEffect, useState } from "react";
import { StatsCard } from "./StatsCard";
import { QuickActions } from "./QuickActions";
import { RecentBookings } from "./RecentBookings";
import { NotificationCenter } from "./NotificationCenter";
import { EarningsChart } from "./EarningsChart";
import api from "../../utils/api";

/**
 * High‑level dashboard component. Fetches analytics metrics from the
 * backend and renders various widgets such as stats cards, charts,
 * recent bookings and notifications.
 */
export const UserDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<{ [key: string]: number | undefined }>({});

  useEffect(() => {
    async function fetchMetrics() {
      try {
        const res = await api.get("/analytics/metrics");
        setMetrics(res.data);
      } catch (err) {
        console.error(err);
      }
    }
    fetchMetrics();
  }, []);

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-2xl font-semibold">Dashboard</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard label="Total GPUs" value={metrics.total_gpus ?? 0} />
        <StatsCard label="Total Bookings" value={metrics.total_bookings ?? 0} />
        <StatsCard label="Total Revenue" value={(metrics.total_revenue ?? 0).toFixed(2)} />
      </div>
      <QuickActions />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <RecentBookings />
        <NotificationCenter />
      </div>
      <div>
        <h3 className="text-lg font-semibold mb-2">Earnings Over Time</h3>
        <EarningsChart />
      </div>
    </div>
  );
};