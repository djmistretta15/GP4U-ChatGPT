import React from "react";
import { Link } from "react-router-dom";

/**
 * Dashboard quick actions. Provides easy access to common tasks such
 * as making a booking or registering a new GPU.
 */
export const QuickActions: React.FC = () => {
  return (
    <div className="flex space-x-4">
      <Link to="/search" className="bg-blue-500 text-white px-4 py-2 rounded">
        Book a GPU
      </Link>
      <Link to="/owner/register-gpu" className="bg-green-500 text-white px-4 py-2 rounded">
        Register a GPU
      </Link>
    </div>
  );
};