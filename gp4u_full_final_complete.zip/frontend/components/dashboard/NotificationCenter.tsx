import React, { useEffect, useContext } from "react";
import { NotificationContext } from "../../contexts/NotificationContext";

/**
 * Displays the user's notifications. Uses the ``NotificationContext``
 * to fetch and mark notifications as read. For demonstration the
 * user ID is hardcoded to 1.
 */
export const NotificationCenter: React.FC = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("NotificationCenter must be used within NotificationProvider");
  }
  const { notifications, fetchNotifications, markAsRead, loading } = context;
  useEffect(() => {
    fetchNotifications(1);
  }, []);
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Notifications</h3>
      {loading && <p>Loading notifications...</p>}
      <ul className="space-y-2">
        {notifications.map(n => (
          <li key={n.id} className="border p-2 flex justify-between items-center">
            <span className={n.is_read ? "text-gray-500" : "font-medium"}>{n.message}</span>
            {!n.is_read && (
              <button
                onClick={() => markAsRead(n.id)}
                className="text-sm text-blue-600 hover:underline"
              >
                Mark as read
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};