import React from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

/**
 * Chart displaying earnings over the past period. In a real
 * application the data would be fetched from an analytics API. Here
 * static sample data is used for demonstration purposes.
 */
const sampleData = [
  { period: "Jan", earnings: 120 },
  { period: "Feb", earnings: 200 },
  { period: "Mar", earnings: 150 },
  { period: "Apr", earnings: 300 },
  { period: "May", earnings: 250 },
];

export const EarningsChart: React.FC = () => {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={sampleData} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="period" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="earnings" stroke="#8884d8" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};