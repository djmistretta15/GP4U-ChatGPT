import React from "react";

interface StatsCardProps {
  label: string;
  value: string | number;
}

/**
 * Simple card displaying a statistic label and its value. Used in
 * dashboards to surface key metrics.
 */
export const StatsCard: React.FC<StatsCardProps> = ({ label, value }) => {
  return (
    <div className="border rounded p-4 bg-white shadow-sm">
      <div className="text-gray-600 text-sm">{label}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  );
};