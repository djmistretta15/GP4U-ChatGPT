import React, { useEffect } from "react";
import { useBooking } from "../../hooks/useBooking";
import { BookingCard } from "../booking/BookingCard";

/**
 * Displays a list of the most recent bookings for the current user. It
 * uses the booking context to fetch and store bookings. For
 * demonstration the user ID is hardcoded to 1; in a real app the
 * authenticated user's ID would be passed.
 */
export const RecentBookings: React.FC = () => {
  const { bookings, fetchBookings, loading } = useBooking();
  useEffect(() => {
    fetchBookings(1);
  }, []);
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Recent Bookings</h3>
      {loading && <p>Loading bookings...</p>}
      {!loading && bookings.length === 0 && <p>No bookings yet.</p>}
      <div className="space-y-2">
        {bookings.map(b => (
          <BookingCard key={b.id} booking={b} />
        ))}
      </div>
    </div>
  );
};