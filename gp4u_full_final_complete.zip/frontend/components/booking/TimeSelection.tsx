import React, { useState } from "react";

interface TimeSelectionProps {
  onSelect: (start: string, end: string) => void;
  onBack: () => void;
}

/**
 * Allows the user to select start and end times for a booking. Uses
 * native HTML5 datetime inputs for simplicity. Calls the provided
 * callback with ISO strings when the user proceeds.
 */
export const TimeSelection: React.FC<TimeSelectionProps> = ({ onSelect, onBack }) => {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  const handleNext = () => {
    if (!start || !end) {
      alert("Please select both start and end times");
      return;
    }
    if (new Date(end) <= new Date(start)) {
      alert("End time must be after start time");
      return;
    }
    onSelect(start, end);
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Select Time</h3>
      <div className="space-y-2">
        <label className="block">
          Start time:
          <input
            type="datetime-local"
            value={start}
            onChange={e => setStart(e.target.value)}
            className="border p-2 w-full"
          />
        </label>
        <label className="block">
          End time:
          <input
            type="datetime-local"
            value={end}
            onChange={e => setEnd(e.target.value)}
            className="border p-2 w-full"
          />
        </label>
        <div className="flex space-x-2 mt-2">
          <button onClick={onBack} className="bg-gray-300 px-3 py-1 rounded">
            Back
          </button>
          <button
            onClick={handleNext}
            className="bg-blue-500 text-white px-4 py-1 rounded"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};