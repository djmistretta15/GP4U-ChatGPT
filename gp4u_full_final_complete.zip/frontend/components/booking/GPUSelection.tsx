import React, { useEffect } from "react";
import { useGPU } from "../../hooks/useGPU";

interface GPUSelectionProps {
  onSelect: (gpuId: number) => void;
}

/**
 * GPU selection step. Displays a list of available GPUs and allows
 * the user to choose one. When a GPU is selected the parent wizard
 * moves to the next step.
 */
export const GPUSelection: React.FC<GPUSelectionProps> = ({ onSelect }) => {
  const { gpus, loading, fetchGPUs } = useGPU();
  useEffect(() => {
    fetchGPUs();
  }, []);
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Select a GPU</h3>
      {loading && <p>Loading GPUs...</p>}
      <ul className="space-y-2">
        {gpus.map(gpu => (
          <li key={gpu.id} className="border p-2 flex justify-between items-center">
            <div>
              <div className="font-medium">{gpu.name}</div>
              <div className="text-sm text-gray-600">{gpu.manufacturer}</div>
            </div>
            <button
              onClick={() => onSelect(gpu.id)}
              className="bg-blue-500 text-white px-3 py-1 rounded"
            >
              Choose
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};