import React from "react";
import { Booking } from "../../contexts/BookingContext";
import { formatDateTime, formatCurrency } from "../../utils/formatting";

/**
 * Card component that displays a booking summary.
 */
export const BookingCard: React.FC<{ booking: Booking }> = ({ booking }) => {
  return (
    <div className="border rounded p-4 shadow-sm">
      <h3 className="font-semibold mb-2">Booking #{booking.id}</h3>
      <p>GPU ID: {booking.gpu_id}</p>
      {booking.start_time && <p>Start: {formatDateTime(booking.start_time)}</p>}
      {booking.end_time && <p>End: {formatDateTime(booking.end_time)}</p>}
      {booking.total_price !== undefined && (
        <p>Total: {formatCurrency(booking.total_price)}</p>
      )}
      <p>Status: {booking.status ?? "pending"}</p>
    </div>
  );
};