import React, { useState } from "react";
import { GPUSelection } from "./GPUSelection";
import { TimeSelection } from "./TimeSelection";
import { PaymentStep } from "./PaymentStep";
import { BookingConfirmation } from "./BookingConfirmation";
import { useBooking } from "../../hooks/useBooking";
import { Booking } from "../../contexts/BookingContext";

/**
 * Multi‑step form for creating a booking. This simple wizard allows a
 * user to select a GPU, choose start and end times, optionally pay
 * (simulated) and then shows a confirmation message. Each step is
 * rendered conditionally based on the current step state.
 */
export const BookingWizard: React.FC = () => {
  const [step, setStep] = useState(1);
  const [bookingData, setBookingData] = useState<Partial<Booking>>({});
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const { createBooking } = useBooking();

  const next = () => setStep(prev => prev + 1);
  const prev = () => setStep(prev => prev - 1);

  const handleConfirm = async () => {
    const created = await createBooking(bookingData);
    if (created) {
      setConfirmedBooking(created);
      next();
    }
  };

  if (confirmedBooking) {
    return <BookingConfirmation booking={confirmedBooking} />;
  }

  return (
    <div className="border rounded p-4 max-w-lg mx-auto">
      {step === 1 && (
        <GPUSelection
          onSelect={gpuId => {
            setBookingData({ ...bookingData, gpu_id: gpuId });
            next();
          }}
        />
      )}
      {step === 2 && (
        <TimeSelection
          onSelect={(start, end) => {
            setBookingData({ ...bookingData, start_time: start, end_time: end });
            next();
          }}
          onBack={prev}
        />
      )}
      {step === 3 && (
        <PaymentStep
          booking={bookingData}
          onComplete={() => {
            handleConfirm();
          }}
          onBack={prev}
        />
      )}
    </div>
  );
};