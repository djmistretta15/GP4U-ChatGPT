import React from "react";
import { Booking } from "../../contexts/BookingContext";

/**
 * Component to display a success message after a booking has been created.
 */
export const BookingConfirmation: React.FC<{ booking: Booking }> = ({ booking }) => {
  return (
    <div className="p-4 border rounded bg-green-50">
      <h3 className="font-semibold mb-2">Booking Confirmed!</h3>
      <p>Your booking #{booking.id} has been created successfully.</p>
    </div>
  );
};