import React, { useState } from "react";
import { Booking } from "../../contexts/BookingContext";
import { usePayment } from "../../hooks/usePayment";
import { formatCurrency } from "../../utils/formatting";

interface PaymentStepProps {
  booking: Partial<Booking>;
  onComplete: () => void;
  onBack: () => void;
}

/**
 * Payment step in the booking wizard. Allows the user to review the
 * booking cost and simulate a payment. In a real implementation this
 * would integrate with Stripe or another payment processor.
 */
export const PaymentStep: React.FC<PaymentStepProps> = ({ booking, onComplete, onBack }) => {
  const { createPayment, loading } = usePayment();
  const [error, setError] = useState<string | null>(null);

  const handlePayment = async () => {
    setError(null);
    if (!booking.id || !booking.total_price) {
      // In a real scenario the booking would be created before payment
      // and total_price would be populated. For demonstration we skip payment.
      onComplete();
      return;
    }
    try {
      await createPayment(booking.id, booking.total_price);
      onComplete();
    } catch (err) {
      console.error(err);
      setError("Payment failed");
    }
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Payment</h3>
      {booking.total_price !== undefined && (
        <p className="mb-2">Total due: {formatCurrency(booking.total_price)}</p>
      )}
      {error && <p className="text-red-600 mb-2">{error}</p>}
      <div className="flex space-x-2">
      <button onClick={onBack} className="bg-gray-300 px-3 py-1 rounded">
        Back
      </button>
      <button
        onClick={handlePayment}
        disabled={loading}
        className="bg-green-500 text-white px-4 py-1 rounded disabled:opacity-50"
      >
        {loading ? "Processing..." : "Pay & Confirm"}
      </button>
      </div>
    </div>
  );
};