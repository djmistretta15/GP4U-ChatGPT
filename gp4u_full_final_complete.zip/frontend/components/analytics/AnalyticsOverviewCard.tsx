import { useEffect, useState } from "react";
import api from "@/utils/api";

/**
 * AnalyticsOverviewCard component.
 *
 * Fetches aggregated platform metrics from the backend and displays
 * them in a simple card.  Administrators can use this component to
 * monitor the health and usage of the marketplace at a glance.
 */
export default function AnalyticsOverviewCard() {
  const [metrics, setMetrics] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const fetchMetrics = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await api.get("/analytics-overview");
        setMetrics(response.data);
      } catch (err: any) {
        setError(err?.response?.data?.detail || "Failed to fetch analytics");
      } finally {
        setLoading(false);
      }
    };
    fetchMetrics();
  }, []);

  return (
    <div className="p-4 bg-white rounded shadow-sm max-w-md">
      <h2 className="text-xl font-semibold mb-2">Platform Overview</h2>
      {loading && <p>Loading…</p>}
      {error && <p className="text-red-600">{error}</p>}
      {metrics && (
        <ul className="list-none space-y-1 mt-2">
          <li>Users: {metrics.users}</li>
          <li>GPUs: {metrics.gpus}</li>
          <li>Bookings: {metrics.bookings}</li>
          <li>Payments: {metrics.payments}</li>
          <li>Reviews: {metrics.reviews}</li>
        </ul>
      )}
    </div>
  );
}