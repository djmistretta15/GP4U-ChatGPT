import React from "react";
import { UserDashboard } from "../components/dashboard/UserDashboard";

/**
 * Page that renders the main user dashboard. Assumes the user is
 * authenticated. In a full application you would include auth
 * guarding here.
 */
export const DashboardPage: React.FC = () => {
  return <UserDashboard />;
};