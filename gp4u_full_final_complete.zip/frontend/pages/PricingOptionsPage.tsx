import React, { useState } from "react";
import api from "../utils/api";

/**
 * Pricing options page.
 *
 * Allows a user to enter a GPU ID and fetch base/dynamic pricing
 * options from the backend.  Displays the results in a simple card.
 */
const PricingOptionsPage: React.FC = () => {
  const [gpuId, setGpuId] = useState<string>("");
  const [options, setOptions] = useState<{ base_price: number; dynamic_price: number } | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setOptions(null);
    if (!gpuId) return;
    try {
      const res = await api.get(`/pricing/options/${gpuId}`);
      setOptions(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Failed to fetch pricing options");
    }
  };
  return (
    <div className="max-w-md mx-auto mt-8 p-4 border rounded">
      <h1 className="text-xl font-semibold mb-4">Pricing Options</h1>
      <form onSubmit={handleSubmit} className="mb-4 flex flex-col gap-2">
        <label htmlFor="gpuId">GPU ID</label>
        <input
          id="gpuId"
          type="number"
          className="border rounded p-2"
          value={gpuId}
          onChange={(e) => setGpuId(e.target.value)}
        />
        <button type="submit" className="bg-blue-500 text-white p-2 rounded">
          Get Pricing
        </button>
      </form>
      {error && <p className="text-red-600">{error}</p>}
      {options && (
        <div className="border rounded p-4 bg-gray-100">
          <p>
            <strong>Base Price:</strong> ${options.base_price.toFixed(2)} / hr
          </p>
          <p>
            <strong>Dynamic Price:</strong> ${options.dynamic_price.toFixed(2)} / hr
          </p>
        </div>
      )}
    </div>
  );
};

export default PricingOptionsPage;