import React from "react";
import ChatbotAssistant from "../components/common/ChatbotAssistant";

/**
 * AssistantPage renders the AI GPU assistant chat interface.
 *
 * This page can be routed to ``/assistant`` in your app's router. It
 * demonstrates how plugins can surface new UI components without impacting
 * existing pages.
 */
const AssistantPage: React.FC = () => {
  return (
    <div className="max-w-2xl mx-auto mt-8">
      <ChatbotAssistant />
    </div>
  );
};

export default AssistantPage;