import React, { useEffect, useState } from "react";
import api from "../utils/api";

interface UserSettings {
  email_notifications: boolean;
  dark_mode: boolean;
  timezone: string;
}

/**
 * User settings page. Allows viewing and updating personal
 * preferences. Uses the settings API implemented on the backend.
 */
export const SettingsPage: React.FC = () => {
  const userId = 1; // In a real app this would come from auth context
  const [settings, setSettings] = useState<UserSettings>({
    email_notifications: true,
    dark_mode: false,
    timezone: "UTC",
  });
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    async function fetchSettings() {
      try {
        const res = await api.get(`/settings/${userId}`);
        setSettings(res.data);
      } catch (err) {
        console.error(err);
      }
    }
    fetchSettings();
  }, [userId]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.put(`/settings/${userId}`, settings);
      setMessage("Settings saved");
    } catch (err) {
      console.error(err);
      setMessage("Failed to save settings");
    }
  };

  return (
    <div className="p-4 max-w-md">
      <h2 className="text-xl font-semibold mb-2">Settings</h2>
      {message && <p className="mb-2">{message}</p>}
      <form onSubmit={handleSave} className="space-y-2">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={settings.email_notifications}
            onChange={e => setSettings({ ...settings, email_notifications: e.target.checked })}
          />
          <span>Enable email notifications</span>
        </label>
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={settings.dark_mode}
            onChange={e => setSettings({ ...settings, dark_mode: e.target.checked })}
          />
          <span>Enable dark mode</span>
        </label>
        <label className="block">
          Timezone:
          <input
            type="text"
            value={settings.timezone}
            onChange={e => setSettings({ ...settings, timezone: e.target.value })}
            className="border p-2 w-full"
          />
        </label>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2">
          Save
        </button>
      </form>
    </div>
  );
};