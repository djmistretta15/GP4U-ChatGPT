import React, { useState } from "react";
import SustainabilitySummaryCard from "../components/sustainability/SustainabilitySummaryCard";
import api from "../utils/api";

interface GPUMetrics {
  gpu_name: string;
  power_watts: number;
  energy_kwh_per_hour: number;
  carbon_kg_per_hour: number;
  offset_cost_per_hour: number;
  suggested_action: string;
}

const SustainabilityPage: React.FC = () => {
  const [gpuId, setGpuId] = useState<string>("");
  const [metrics, setMetrics] = useState<GPUMetrics | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const handleFetch = async () => {
    if (!gpuId) return;
    setLoading(true);
    setError(null);
    setMetrics(null);
    try {
      const response = await api.get(`/sustainability/gpu/${gpuId}`);
      setMetrics(response.data);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to fetch metrics");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Sustainability</h1>
      <SustainabilitySummaryCard />
      <div className="bg-white shadow-md rounded-lg p-4 mb-4">
        <h2 className="text-lg font-semibold mb-2">Check GPU Carbon Footprint</h2>
        <div className="flex flex-col sm:flex-row items-center gap-2 mb-2">
          <input
            type="number"
            placeholder="Enter GPU ID"
            value={gpuId}
            onChange={(e) => setGpuId(e.target.value)}
            className="border p-2 rounded flex-1"
          />
          <button
            onClick={handleFetch}
            className="bg-blue-500 text-white px-4 py-2 rounded"
            disabled={loading}
          >
            {loading ? "Loading…" : "Fetch"}
          </button>
        </div>
        {error && <p className="text-red-500">{error}</p>}
        {metrics && (
          <div className="mt-2 text-sm">
            <p className="font-semibold">{metrics.gpu_name}</p>
            <p>Power: {metrics.power_watts.toFixed(2)} W</p>
            <p>Energy: {metrics.energy_kwh_per_hour.toFixed(3)} kWh/h</p>
            <p>Carbon: {metrics.carbon_kg_per_hour.toFixed(3)} kg CO₂/h</p>
            <p>Offset Cost: ${metrics.offset_cost_per_hour.toFixed(2)} per h</p>
            <p className="italic">{metrics.suggested_action}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SustainabilityPage;