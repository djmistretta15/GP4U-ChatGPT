import React, { useContext } from "react";
import { LocalizationContext } from "../contexts/LocalizationContext";
import LanguageSelector from "../components/common/LanguageSelector";

/**
 * Localization page.
 *
 * Demonstrates the use of the localisation context by displaying a few
 * translation strings and allowing the user to switch between supported
 * languages using the ``LanguageSelector`` component.  This page is
 * intentionally simple to illustrate the concept; real applications
 * would wrap the entire app in the ``LocalizationProvider`` and use
 * translation strings throughout the UI.
 */
const LocalizationPage: React.FC = () => {
  const context = useContext(LocalizationContext);
  if (!context) {
    return <p>Loading…</p>;
  }
  const { translations } = context;
  return (
    <div className="max-w-md mx-auto mt-8 p-4 border rounded">
      <h1 className="text-xl font-semibold mb-4">Localization Demo</h1>
      <div className="mb-4">
        <label htmlFor="language" className="mr-2 font-medium">
          Select Language:
        </label>
        <LanguageSelector />
      </div>
      <div className="space-y-2">
        <p>
          <strong>Welcome:</strong> {translations.welcome || "Welcome"}
        </p>
        <p>
          <strong>Search:</strong> {translations.search || "Search"}
        </p>
        <p>
          <strong>Book:</strong> {translations.book || "Book"}
        </p>
        <p>
          <strong>Price:</strong> {translations.price || "Price"}
        </p>
        <p>
          <strong>Language:</strong> {translations.language || "Language"}
        </p>
      </div>
    </div>
  );
};

export default LocalizationPage;