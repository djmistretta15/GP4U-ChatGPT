import React from "react";
import GPURecommendationForm from "../components/common/GPURecommendationForm";

/**
 * RecommendationPage
 *
 * Page component that wraps the GPURecommendationForm.  Users can
 * navigate to this page to obtain GPU recommendations based on their
 * workload descriptions.  As with other pages, this should be
 * integrated into the application's routing and layout in a full
 * implementation.
 */
export const RecommendationPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <GPURecommendationForm />
    </div>
  );
};