import React, { useEffect } from "react";
import { SearchBar } from "../components/search/SearchBar";
import { GPUList } from "../components/gpu/GPUList";
import { useGPU } from "../hooks/useGPU";

/**
 * Home page. Displays a search bar and a grid of GPUs. On load it
 * fetches all GPUs. Users can search from this page as well.
 */
export const HomePage: React.FC = () => {
  const { gpus, fetchGPUs, searchGPUs, loading } = useGPU();
  useEffect(() => {
    fetchGPUs();
  }, []);
  return (
    <div className="p-4 space-y-4">
      <SearchBar onSearch={searchGPUs} />
      {loading && <p>Loading GPUs...</p>}
      {!loading && <GPUList gpus={gpus} />}
    </div>
  );
};