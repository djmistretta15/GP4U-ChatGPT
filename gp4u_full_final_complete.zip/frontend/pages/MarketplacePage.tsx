import React from "react";
import OrderForm from "../components/marketplace/OrderForm";
import OrderList from "../components/marketplace/OrderList";

/**
 * MarketplacePage
 *
 * Combines the OrderForm and OrderList components to provide a
 * simple marketplace UI.  Renters can submit new orders and see
 * existing ones.  Future enhancements could include filtering,
 * searching and order matching status.
 */
export const MarketplacePage: React.FC = () => {
  return (
    <div className="container mx-auto p-4 space-y-4">
      <OrderForm />
      <OrderList />
    </div>
  );
};