import React from "react";
import { OwnerDashboard } from "../components/owner/OwnerDashboard";

/**
 * Owner dashboard page. Requires user to have owner privileges. In a
 * real application you would guard this route based on the user's
 * roles. Here it simply renders the OwnerDashboard component.
 */
export const OwnerDashboardPage: React.FC = () => {
  return <OwnerDashboard />;
};