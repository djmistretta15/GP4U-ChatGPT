import React from "react";
import UserLevelsSelector from "../components/community/UserLevelsSelector";

/**
 * UserLevelsPage
 *
 * Page component that renders the UserLevelsSelector.  This page can be
 * navigated to via the router to allow users to choose their experience
 * level and see which features are recommended.  Additional UI such as
 * breadcrumbs or sidebars can be added here in a full implementation.
 */
export const UserLevelsPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <UserLevelsSelector />
    </div>
  );
};