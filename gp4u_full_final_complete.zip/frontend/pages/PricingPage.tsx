import React from "react";
import PriceSuggestionForm from "../components/pricing/PriceSuggestionForm";

/**
 * PricingPage
 *
 * Page component that hosts the PriceSuggestionForm.  Owners or
 * administrators can visit this page to obtain dynamic pricing
 * suggestions for their GPUs.  This page is intentionally simple and
 * can be integrated into a larger dashboard or settings area.
 */
export const PricingPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <PriceSuggestionForm />
    </div>
  );
};