import React from "react";
import { BookingWizard } from "../components/booking/BookingWizard";

/**
 * Page for creating a new booking. Wraps the ``BookingWizard``
 * component. Could be extended to accept a GPU ID via route params.
 */
export const BookingPage: React.FC = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-4">Create a Booking</h2>
      <BookingWizard />
    </div>
  );
};