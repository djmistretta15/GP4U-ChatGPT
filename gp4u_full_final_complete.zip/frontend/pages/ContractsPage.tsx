import React, { useState } from "react";
import ContractForm from "../components/contracts/ContractForm";
import ContractList from "../components/contracts/ContractList";

const ContractsPage: React.FC = () => {
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [userIdForList, setUserIdForList] = useState<number>(0);
  const [userIdInput, setUserIdInput] = useState<string>("");

  const handleContractCreated = () => {
    // Trigger list refresh
    setRefreshKey((prev) => prev + 1);
  };

  const handleListFetch = (e: React.FormEvent) => {
    e.preventDefault();
    const id = parseInt(userIdInput, 10);
    if (!isNaN(id)) {
      setUserIdForList(id);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Contracts</h1>
      <ContractForm onCreated={handleContractCreated} />
      <div className="bg-white shadow-md rounded-lg p-4 mb-4">
        <h2 className="text-lg font-semibold mb-2">View User Contracts</h2>
        <form onSubmit={handleListFetch} className="flex gap-2 items-center mb-2">
          <input
            type="number"
            placeholder="User ID"
            value={userIdInput}
            onChange={(e) => setUserIdInput(e.target.value)}
            className="border p-2 rounded"
          />
          <button
            type="submit"
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Load Contracts
          </button>
        </form>
        {userIdForList > 0 && (
          <ContractList key={refreshKey} userId={userIdForList} />
        )}
      </div>
    </div>
  );
};

export default ContractsPage;