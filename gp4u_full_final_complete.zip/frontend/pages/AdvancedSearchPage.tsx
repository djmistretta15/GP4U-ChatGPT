import React from "react";
import AdvancedSearchForm from "../components/search/AdvancedSearchForm";

/**
 * AdvancedSearchPage
 *
 * Hosts the AdvancedSearchForm for users to perform detailed GPU
 * searches using multiple filters.  Results are displayed within
 * the form.  This page can be linked from a navigation menu.
 */
export const AdvancedSearchPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <AdvancedSearchForm />
    </div>
  );
};