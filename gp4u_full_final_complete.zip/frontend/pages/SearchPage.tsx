import React, { useEffect, useState } from "react";
import { SearchBar } from "../components/search/SearchBar";
import { FilterPanel } from "../components/search/FilterPanel";
import { SortOptions } from "../components/search/SortOptions";
import { GPUList } from "../components/gpu/GPUList";
import { useGPU } from "../hooks/useGPU";

/**
 * Search page. Provides search bar, filters and sort controls along
 * with a grid of results. Uses the ``useGPU`` hook to perform
 * searches. Sorting is applied client‑side.
 */
export const SearchPage: React.FC = () => {
  const { gpus, searchGPUs, loading } = useGPU();
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [sortBy, setSortBy] = useState<string>("");

  useEffect(() => {
    // Trigger a search when filters change
    const query = filters.q ?? "";
    searchGPUs(query);
  }, [filters]);

  const sortedGpus = [...gpus].sort((a, b) => {
    if (sortBy === "price_asc") return (a.price_per_hour ?? 0) - (b.price_per_hour ?? 0);
    if (sortBy === "price_desc") return (b.price_per_hour ?? 0) - (a.price_per_hour ?? 0);
    if (sortBy === "performance_desc") return (b.performance_score ?? 0) - (a.performance_score ?? 0);
    return 0;
  });

  return (
    <div className="p-4 space-y-4">
      <SearchBar onSearch={query => setFilters({ ...filters, q: query })} />
      <FilterPanel onFilterChange={setFilters} />
      <SortOptions onSortChange={setSortBy} />
      {loading && <p>Searching...</p>}
      {!loading && <GPUList gpus={sortedGpus} />}
    </div>
  );
};