import React from "react";
import MatchOrdersButton from "../components/marketplace/MatchOrdersButton";

/**
 * MatchOrdersPage
 *
 * Provides a page where an administrator can trigger the order
 * matching process.  It displays the IDs of matched orders upon
 * completion.  Future enhancements could include more detailed
 * matching reports or automatic scheduling.
 */
export const MatchOrdersPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <MatchOrdersButton />
    </div>
  );
};