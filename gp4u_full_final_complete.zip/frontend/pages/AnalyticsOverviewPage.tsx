import React from "react";
import AnalyticsOverviewCard from "../components/analytics/AnalyticsOverviewCard";

/**
 * AnalyticsOverviewPage
 *
 * Page component that renders the AnalyticsOverviewCard.  It shows
 * aggregated platform metrics for administrators to monitor the
 * system's health.  This page could be enhanced with charts,
 * filtering or real‑time updates in future iterations.
 */
export const AnalyticsOverviewPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <AnalyticsOverviewCard />
    </div>
  );
};