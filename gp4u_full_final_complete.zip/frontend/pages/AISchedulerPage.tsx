import React from "react";
import AISchedulerButton from "../components/scheduler/AISchedulerButton";

const AISchedulerPage: React.FC = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">AI Scheduler</h1>
      <AISchedulerButton />
    </div>
  );
};

export default AISchedulerPage;