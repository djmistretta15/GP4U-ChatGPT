import React, { useState, useEffect } from "react";
import api from "../utils/api";
import { useAuth } from "../hooks/useAuth";

/**
 * Community page.
 *
 * Provides simple controls for following and unfollowing GPU owners and
 * displays the list of followed owners.  This demonstrates how
 * community social features can be surfaced in the UI.
 */
const CommunityPage: React.FC = () => {
  const { user } = useAuth();
  const [ownerId, setOwnerId] = useState<string>("");
  const [following, setFollowing] = useState<number[]>([]);
  const [error, setError] = useState<string | null>(null);

  const fetchFollowing = async () => {
    try {
      const res = await api.get("/community/following");
      setFollowing(res.data.following || []);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Failed to load following list");
    }
  };

  useEffect(() => {
    if (user) {
      fetchFollowing();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleFollow = async () => {
    setError(null);
    if (!ownerId) return;
    try {
      await api.post(`/community/follow/${ownerId}`);
      setOwnerId("");
      fetchFollowing();
    } catch (err: any) {
      setError(err.response?.data?.detail || "Failed to follow user");
    }
  };

  const handleUnfollow = async (id: number) => {
    setError(null);
    try {
      await api.delete(`/community/follow/${id}`);
      fetchFollowing();
    } catch (err: any) {
      setError(err.response?.data?.detail || "Failed to unfollow user");
    }
  };

  if (!user) {
    return <p>Please log in to manage your community.</p>;
  }

  return (
    <div className="max-w-md mx-auto mt-8 p-4 border rounded">
      <h1 className="text-xl font-semibold mb-4">Community</h1>
      <div className="flex gap-2 mb-4">
        <input
          type="number"
          value={ownerId}
          onChange={(e) => setOwnerId(e.target.value)}
          placeholder="Owner ID"
          className="border rounded p-2 flex-grow"
        />
        <button onClick={handleFollow} className="bg-green-500 text-white p-2 rounded">
          Follow
        </button>
      </div>
      {error && <p className="text-red-600">{error}</p>}
      <h2 className="text-lg font-semibold mt-4 mb-2">You are following:</h2>
      <ul className="list-disc list-inside">
        {following.map((owner) => (
          <li key={owner} className="flex items-center justify-between">
            <span>Owner {owner}</span>
            <button
              onClick={() => handleUnfollow(owner)}
              className="text-red-500 hover:underline"
            >
              Unfollow
            </button>
          </li>
        ))}
        {following.length === 0 && <li>No followed owners yet.</li>}
      </ul>
    </div>
  );
};

export default CommunityPage;