import React, { createContext, useState, type ReactNode } from "react";
import api from "../utils/api";

/**
 * Notification interface as returned by the backend.
 */
export interface Notification {
  id: number;
  user_id: number;
  message: string;
  is_read: boolean;
  created_at: string;
}

interface NotificationContextValue {
  notifications: Notification[];
  loading: boolean;
  fetchNotifications: (userId: number) => Promise<void>;
  markAsRead: (notificationId: number) => Promise<void>;
}

export const NotificationContext = createContext<NotificationContextValue | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchNotifications = async (userId: number) => {
    setLoading(true);
    try {
      const res = await api.get(`/notifications/${userId}`);
      setNotifications(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: number) => {
    setLoading(true);
    try {
      const res = await api.put(`/notifications/${notificationId}`);
      const updated = res.data as Notification;
      setNotifications(prev => prev.map(n => (n.id === updated.id ? updated : n)));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <NotificationContext.Provider
      value={{ notifications, loading, fetchNotifications, markAsRead }}
    >
      {children}
    </NotificationContext.Provider>
  );
};