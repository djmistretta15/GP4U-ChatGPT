import React, { createContext, useState, type ReactNode } from "react";
import api from "../utils/api";

/**
 * Types describing the authentication context. The context exposes the
 * authenticated user (if any), loading state, and functions to login,
 * signup and logout. In a production application tokens would be
 * persisted to cookies or local storage and automatically injected
 * into the Axios instance.
 */
interface Credentials {
  email: string;
  password: string;
}

interface AuthContextValue {
  user: any;
  loading: boolean;
  login: (credentials: Credentials) => Promise<void>;
  signup: (credentials: Credentials) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

export const AuthContext = createContext<AuthContextValue | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const login = async ({ email, password }: Credentials) => {
    setLoading(true);
    try {
      const response = await api.post("/auth/login", null, {
        params: { email, password },
      });
      // In a real implementation the backend should return user info
      setUser({ email, token: response.data.access_token });
    } finally {
      setLoading(false);
    }
  };

  const signup = async ({ email, password }: Credentials) => {
    setLoading(true);
    try {
      // GP4U backend does not yet implement signup; this is a stub
      await api.post("/auth/register", { email, password });
      setUser({ email });
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, loading, login, signup, logout, isAuthenticated: Boolean(user) }}
    >
      {children}
    </AuthContext.Provider>
  );
};