import React, { createContext, useState, type ReactNode } from "react";
import api from "../utils/api";

/**
 * Types describing a booking. These should reflect the API's booking
 * schema. Optional fields are used to allow incremental creation
 * through a wizard.
 */
export interface Booking {
  id?: number;
  user_id?: number;
  gpu_id?: number;
  start_time?: string;
  end_time?: string;
  status?: string;
  total_price?: number;
}

interface BookingContextValue {
  bookings: Booking[];
  loading: boolean;
  fetchBookings: (userId: number) => Promise<void>;
  createBooking: (data: Partial<Booking>) => Promise<Booking | undefined>;
}

export const BookingContext = createContext<BookingContextValue | undefined>(undefined);

export const BookingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchBookings = async (userId: number) => {
    setLoading(true);
    try {
      const res = await api.get(`/bookings/${userId}`);
      setBookings(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const createBooking = async (data: Partial<Booking>) => {
    setLoading(true);
    try {
      const res = await api.post("/bookings", data);
      const newBooking: Booking = res.data;
      setBookings(prev => [...prev, newBooking]);
      return newBooking;
    } catch (err) {
      console.error(err);
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  return (
    <BookingContext.Provider value={{ bookings, loading, fetchBookings, createBooking }}>
      {children}
    </BookingContext.Provider>
  );
};