import React, { createContext, useState, useEffect, type ReactNode } from "react";
import api from "../utils/api";

/**
 * Context value describing the current language and translations.
 */
export interface LocalizationContextValue {
  language: string;
  translations: Record<string, string>;
  setLanguage: (lang: string) => Promise<void>;
  availableLanguages: string[];
}

/**
 * React context for localisation.  Components can consume this context to
 * retrieve the current language, translation strings and change the
 * language at runtime.  The provider fetches translations from the
 * backend localisation API.
 */
export const LocalizationContext = createContext<LocalizationContextValue | undefined>(
  undefined,
);

export const LocalizationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, updateLanguage] = useState<string>("en");
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [availableLanguages, setAvailableLanguages] = useState<string[]>([]);

  // Fetch the list of supported languages on mount
  useEffect(() => {
    const fetchLanguages = async () => {
      try {
        const res = await api.get("/localization/languages");
        setAvailableLanguages(res.data.languages || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchLanguages();
  }, []);

  // Fetch translations whenever the language changes
  useEffect(() => {
    const fetchTranslations = async (lang: string) => {
      try {
        const res = await api.get(`/localization/${lang}`);
        setTranslations(res.data.translations || {});
      } catch (err) {
        console.error(err);
        setTranslations({});
      }
    };
    fetchTranslations(language);
  }, [language]);

  const setLanguage = async (lang: string) => {
    updateLanguage(lang);
  };

  return (
    <LocalizationContext.Provider value={{ language, translations, setLanguage, availableLanguages }}>
      {children}
    </LocalizationContext.Provider>
  );
};