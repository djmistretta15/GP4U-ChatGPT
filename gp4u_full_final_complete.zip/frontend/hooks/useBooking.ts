import { useContext } from "react";
import { BookingContext } from "../contexts/BookingContext";

/**
 * Custom hook to access the booking context. Throws an error if used
 * outside of ``BookingProvider``.
 */
export function useBooking() {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error("useBooking must be used within a BookingProvider");
  }
  return context;
}