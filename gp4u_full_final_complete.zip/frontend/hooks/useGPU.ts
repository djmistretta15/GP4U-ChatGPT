import { useState } from "react";
import api from "../utils/api";

/**
 * Interface describing a GPU as returned by the backend.
 */
export interface GPU {
  id: number;
  name: string;
  manufacturer: string;
  memory_gb?: number;
  price_per_hour?: number;
  performance_score?: number;
}

/**
 * Custom hook for fetching and searching GPUs.
 */
export function useGPU() {
  const [gpus, setGpus] = useState<GPU[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchGPUs = async () => {
    setLoading(true);
    try {
      const res = await api.get("/gpus");
      setGpus(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const searchGPUs = async (query: string) => {
    setLoading(true);
    try {
      const res = await api.get("/search/gpus", { params: { q: query } });
      setGpus(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return {
    gpus,
    loading,
    fetchGPUs,
    searchGPUs,
  };
}