import { useState } from "react";
import api from "../utils/api";

/**
 * Hook for creating payments via the backend. Returns a function to
 * create a payment along with loading state. The backend should
 * integrate with Stripe or another payment provider to complete
 * transactions.
 */
export function usePayment() {
  const [loading, setLoading] = useState(false);

  const createPayment = async (bookingId: number, amount: number) => {
    setLoading(true);
    try {
      const res = await api.post("/payments", {
        booking_id: bookingId,
        amount,
      });
      return res.data;
    } catch (err) {
      console.error(err);
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  return { createPayment, loading };
}