/**
 * Miscellaneous helper functions.
 */

/**
 * Conditionally join class names together.
 *
 * This function accepts any number of arguments which can be strings or
 * falsy values. All truthy values will be joined together with a
 * single space. Falsy values will be ignored. This is useful for
 * building Tailwind or CSS class name strings.
 */
export function classNames(...classes: (string | false | null | undefined)[]): string {
  return classes.filter(Boolean).join(" ");
}

/**
 * Sleep for a given number of milliseconds. Useful for testing and
 * simulating network latency.
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
