/**
 * Form validation utilities.
 *
 * These helpers provide simple validation for common input fields. For
 * more complex validation consider using a library such as Zod or
 * Yup in conjunction with React Hook Form.
 */

/** Validate an email address using a basic regex. */
export function isValidEmail(email: string): boolean {
  return /^\S+@\S+\.\S+$/.test(email);
}

/** Validate that a password meets minimal complexity requirements. */
export function isStrongPassword(password: string): boolean {
  // At least 8 characters
  return password.length >= 8;
}
