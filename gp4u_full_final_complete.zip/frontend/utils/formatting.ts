/**
 * Formatting utilities.
 *
 * This module provides helper functions for formatting dates and
 * currency values consistently throughout the application.
 */

/**
 * Format a number as a currency string.
 *
 * @param value The numeric value to format.
 * @param currency The ISO 4217 currency code (default: "USD").
 * @param locales An optional BCP 47 locale string used for formatting.
 */
export function formatCurrency(value: number, currency: string = "USD", locales = "en-US"): string {
  return new Intl.NumberFormat(locales, { style: "currency", currency }).format(value);
}

/**
 * Format a date/time value as a human‑readable string.
 *
 * @param date A Date object or ISO date string.
 * @param locales An optional BCP 47 locale string used for formatting.
 */
export function formatDateTime(date: Date | string, locales = "en-US"): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleString(locales);
}
