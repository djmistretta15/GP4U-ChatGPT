/**
 * Axios API wrapper.
 *
 * This module exports a preconfigured Axios instance that points to the
 * backend API. The base URL is read from the ``VITE_API_URL`` environment
 * variable if available, or defaults to ``http://localhost:8000/api/v1``.
 */
import axios from "axios";

const baseURL: string =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_API_URL) ||
  "http://localhost:8000/api/v1";

/**
 * A configured Axios instance for making API requests. All relative
 * request paths will be prefixed with the configured base URL. The
 * instance is configured to include credentials to support cookie
 * authentication if enabled on the backend.
 */
const api = axios.create({
  baseURL,
  withCredentials: true,
});

export default api;
