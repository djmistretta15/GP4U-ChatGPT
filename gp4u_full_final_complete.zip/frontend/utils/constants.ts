/**
 * Application constants.
 *
 * This module exports reusable constants used throughout the frontend.
 */

/**
 * The base URL for the GP4U API. In development this will point to
 * ``http://localhost:8000/api/v1`` unless overridden by the
 * ``VITE_API_URL`` environment variable.
 */
export const API_BASE_URL: string =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_API_URL) ||
  "http://localhost:8000/api/v1";

/** Default currency used for price formatting. */
export const DEFAULT_CURRENCY = "USD";

/**
 * List of supported OAuth providers. This can be extended when
 * additional providers are implemented on the backend.
 */
export const OAUTH_PROVIDERS: string[] = ["google", "github"];
