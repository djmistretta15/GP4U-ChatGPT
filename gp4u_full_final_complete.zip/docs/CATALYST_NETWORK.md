# Catalyst Network

The Catalyst network layer powers job routing, failover and health
monitoring for GP4U's distributed GPU infrastructure. It is composed
of lightweight Python modules that encapsulate the following
responsibilities:

## Checkpoint System

The checkpoint system (`catalyst/checkpoint_system.py`) persists job
state to storage so that work can resume after a failure. It exposes
two async methods:

- `create_checkpoint(job_id: str, state: dict) -> str` – Serialises
  and saves the job state, returning a checkpoint ID.
- `restore_from_checkpoint(checkpoint_id: str) -> dict` – Restores
  previously saved state.

The default implementation uses the backend `StorageService` to save
JSON objects on the local filesystem. Integrations with remote
storage such as AWS S3 can be added by substituting the storage
backend.

## Failover Manager

The failover manager (`catalyst/failover_manager.py`) coordinates
handover between GPU nodes when one becomes unavailable. It maintains
a list of available nodes and selects the first one when a failover
event occurs. Methods include:

- `register_node(node_id: str)` – Add a node to the pool.
- `deregister_node(node_id: str)` – Remove a node.
- `select_failover_node() -> Optional[str]` – Choose a node for
  failover.

Sophisticated scheduling and priority logic can be implemented on top
of this simple framework.

## Health Monitor

The health monitor (`catalyst/health_monitor.py`) periodically checks
nodes for liveness. Nodes register a callback that returns a boolean
indicating their health. When a check fails the monitor calls a
user‑provided callback to trigger remediation. Its main methods are:

- `add_node(node_id: str, health_check: Callable[[], bool])`
- `remove_node(node_id: str)`
- `set_unhealthy_callback(callback: Callable[[str], None])`
- `check_nodes()`

## Node Operator Manager

The node operator manager (`catalyst/node_operator_manager.py`) keeps
track of operators and the GPUs they contribute. It exposes methods
to register operators, add or remove GPUs and deregister operators
entirely. This management layer allows the platform to know which
hardware belongs to which participant in the network.

## Smart Router

The smart router (`catalyst/smart_router.py`) assigns jobs to GPUs
based on job requirements and GPU characteristics. The provided
implementation uses a simple heuristic that rewards GPUs with higher
memory and lower price:

```
score = memory_gb / (price_per_hour + epsilon)
```

Jobs are routed to the GPU with the highest score. Future versions
could plug in a machine learning model to predict job completion time
and cost for each GPU.
