# GP4U API Documentation

This document provides a high‑level overview of the REST API exposed by
the GP4U backend. The API is implemented using FastAPI and is
versioned under the `/api/v1` prefix. All endpoints return JSON
responses and use standard HTTP status codes to indicate success or
failure.

## Authentication

- `POST /api/v1/auth/login` – Authenticate a user with email and
  password. Returns a JSON object containing a JWT access token on
  success. Invalid credentials result in a `400 Bad Request`.

## GPUs

- `GET /api/v1/gpus/` – Retrieve a list of all registered GPUs. Each
  GPU object includes its `id`, `name`, `manufacturer`, `memory_gb` and
  `price_per_hour`.
- `POST /api/v1/gpus/` – Register a new GPU. Expects a JSON body with
  `name`, `manufacturer`, `memory_gb` and `price_per_hour`. Returns the
  created GPU on success.

## Bookings

- `GET /api/v1/bookings/{user_id}` – List all bookings for the
  specified user. Returns an array of bookings or a 404 if the user
  does not exist.
- `POST /api/v1/bookings/` – Create a new booking. The request body
  should contain `gpu_id`, `start_time` and `end_time` as ISO
  strings. Returns the created booking.

## Payments

- `POST /api/v1/payments/` – Create a payment for a booking. The
  request body should contain `booking_id` and `amount`. Returns the
  created payment on success. If the booking cannot be found the
  endpoint returns a `400 Bad Request`.

## Notifications

- `GET /api/v1/notifications/{user_id}` – Retrieve notifications for a
  user. Returns a list of notification objects with `message`,
  `is_read` and timestamps.
- `PUT /api/v1/notifications/{notification_id}` – Mark a notification
  as read. Returns the updated notification.

## Search

- `GET /api/v1/search/gpus?q={query}` – Search GPUs by name or
  manufacturer. The `q` query parameter must be provided.

## Analytics

- `GET /api/v1/analytics/metrics` – Returns aggregate metrics
  including total GPUs, total bookings, total revenue and average
  utilisation. The implementation of average utilisation is
  intentionally simplistic and can be extended.

## Settings

- `GET /api/v1/settings/{user_id}` – Retrieve user settings such as
  notification preferences and theme. Returns default values if no
  settings exist.
- `PUT /api/v1/settings/{user_id}` – Update user settings. Accepts a
  JSON body matching the `UserSettings` schema (e.g. `{ "dark_mode":
  true }`).
