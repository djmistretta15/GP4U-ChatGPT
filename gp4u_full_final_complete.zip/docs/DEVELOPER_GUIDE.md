# Developer Guide

This guide is intended for developers who wish to contribute to or
extend the GP4U project. It provides an overview of the architecture,
code organisation and best practices for working on the repository.

## Architecture Overview

GP4U consists of three major components:

1. **Backend** – A FastAPI application that provides RESTful
   endpoints, handles authentication, manages data persistence via
   SQLAlchemy and integrates with external services such as SendGrid
   and Stripe.
2. **Frontend** – A React application built with Vite and Tailwind
   CSS. It communicates with the backend via Axios and uses React
   Context/Custom Hooks for state management.
3. **Catalyst Network** – A collection of Python modules that
   implement distributed compute functionality including job
   checkpointing, failover, health monitoring and job routing.

## Running the Project

Follow the instructions in `docs/DEPLOYMENT.md` to set up the
development environment. In summary, you can use Docker Compose or run
the backend and frontend independently via Python and Node.js.

## Code Style

* Python code follows PEP 8 and uses type hints throughout. Use
  `ruff` or `flake8` to check formatting and `mypy` for type
  checking.
* TypeScript/React code uses functional components and hooks. ESLint
  and Prettier are configured via `package.json`.
* Avoid mixing business logic into API routes. Instead, encapsulate
  logic in service classes under `backend/services` and call them
  from the routes.

## Testing

Unit tests live in `backend/tests`. They use `pytest` and the
FastAPI `TestClient`. To run the tests:

```bash
cd gp4u_full/backend
pytest
```

Add tests for any new services or endpoints you create. Strive for
high coverage and include both success and error scenarios.

## Contributing

1. Fork the repository and create a new branch for your feature or bug
   fix.
2. Write descriptive commit messages and keep commits focused.
3. Update or add tests where applicable.
4. Run the test suite and linters locally before submitting a pull
   request.
5. Submit a pull request and describe your changes clearly.

## Future Work

There are many opportunities to extend GP4U including:

- Implementing comprehensive user management (registration,
  password reset, profile updates).
- Adding role‑based access control to differentiate between renters
  and owners.
- Improving the Catalyst smart router with real performance data and
  machine learning.
- Completing the frontend pages for a polished user experience.
