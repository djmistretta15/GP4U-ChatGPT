# User Guide

Welcome to GP4U! This guide will walk you through the process of
renting GPUs, managing your account and getting the most out of the
platform.

## Signing In

Visit the home page and click **Login**. Enter your email and
password to authenticate. If you are new to the platform, click
**Sign Up** to create an account.

## Searching for GPUs

From the home page or the search page you can search for GPUs by
entering keywords into the search bar. The results can be filtered by
manufacturer and sorted by price or performance. Click **Select** on
a GPU to begin the booking process.

## Making a Booking

The booking wizard guides you through selecting a GPU, choosing a
time window and (optionally) paying for your rental. Once your
booking is confirmed it will appear in your dashboard under **Recent
Bookings**. You can view booking details including start and end
times and total price.

## Notifications

You will receive notifications when important events occur, such as
booking confirmations or payment updates. Access your notifications
via the dashboard. You can mark notifications as read to keep your
inbox tidy.

## Managing GPUs (Owners)

If you own GPUs and wish to rent them out on GP4U, navigate to the
owner dashboard. Here you can register new GPUs, view your earnings
and request payouts. Earnings charts show your revenue over time.

## Settings

Visit the Settings page to customise your experience. You can enable
or disable email notifications, toggle dark mode and set your
preferred timezone. These preferences persist across sessions.

## Getting Help

If you encounter any issues or have questions, please refer to the
developer guide for troubleshooting tips or contact support at
support@gp4u.com.
