# Deployment Guide

This guide outlines how to deploy the GP4U application in a local
development environment using Docker as well as how to prepare for
production deployment.

## Local Development with Docker

The easiest way to run GP4U locally is via Docker Compose. Ensure you
have Docker and Docker Compose installed, then run the following:

```bash
cd gp4u_full
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env.local
docker-compose up --build
```

This will start the following services:

| Service  | URL                   | Description                            |
|---------|-----------------------|----------------------------------------|
| Backend | http://localhost:8000 | FastAPI server and API docs at `/docs` |
| Frontend| http://localhost:3000 | React development server               |
| DB      | internal              | PostgreSQL with persisted volume       |
| Redis   | internal              | Redis cache for tasks                  |

## Manual Setup

If you prefer not to use Docker, you can run the backend and frontend
manually. Requirements:

* Python ≥3.11 and virtualenv for the backend
* Node.js ≥18 for the frontend

### Backend

```bash
cd gp4u_full/backend
python -m venv venv
source venv/bin/activate
pip install -r ../config/requirements.txt
uvicorn backend.main:app --reload
```

### Frontend

```bash
cd gp4u_full/frontend
npm install
npm run dev
```

## Production Considerations

For a production deployment consider the following:

- Use `docker-compose.prod.yml` with a production web server such as
  Nginx serving the frontend build and reverse proxying API requests.
- Configure a real database and Redis instance with appropriate
  persistence and backups.
- Set environment variables (e.g. `DATABASE_URL`, `SENDGRID_API_KEY`,
  `STRIPE_API_KEY`) securely via your orchestration platform.
- Enable HTTPS on the load balancer or reverse proxy.
