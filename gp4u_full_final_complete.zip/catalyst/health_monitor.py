"""
Health monitor.

Periodically checks the health of nodes in the Catalyst network. The
monitor can be configured with a callback to notify when a node
becomes unhealthy. In this simple version a node is considered
healthy if it responds to a ping function. Real implementations may
use heartbeats or metrics exposed over HTTP.
"""

from __future__ import annotations

from typing import Callable, Dict


class HealthMonitor:
    """Monitor the health of Catalyst nodes."""

    def __init__(self) -> None:
        self.nodes: Dict[str, Callable[[], bool]] = {}
        self.on_unhealthy: Callable[[str], None] = lambda node_id: None

    def add_node(self, node_id: str, health_check: Callable[[], bool]) -> None:
        """Register a node with its associated health check function."""
        self.nodes[node_id] = health_check

    def remove_node(self, node_id: str) -> None:
        """Remove a node from monitoring."""
        self.nodes.pop(node_id, None)

    def set_unhealthy_callback(self, callback: Callable[[str], None]) -> None:
        """Set a callback that is called when a node becomes unhealthy."""
        self.on_unhealthy = callback

    def check_nodes(self) -> None:
        """Perform health checks on all nodes."""
        for node_id, check in list(self.nodes.items()):
            healthy = False
            try:
                healthy = check()
            except Exception:
                healthy = False
            if not healthy:
                self.on_unhealthy(node_id)

