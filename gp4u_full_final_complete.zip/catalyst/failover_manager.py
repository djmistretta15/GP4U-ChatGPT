"""
Failover manager.

Coordinates failover between GPU nodes in the Catalyst network. When a
node fails the manager selects another available node to resume the job
from a checkpoint. This naive implementation keeps a list of
available node IDs and selects the first one; in a production system
this would involve health checks and prioritisation based on
capabilities.
"""

from __future__ import annotations

from typing import List, Optional


class FailoverManager:
    """Simple failover coordinator for the Catalyst network."""

    def __init__(self, available_nodes: Optional[List[str]] = None) -> None:
        self.available_nodes = available_nodes or []

    def register_node(self, node_id: str) -> None:
        """Register a new node as available for failover."""
        if node_id not in self.available_nodes:
            self.available_nodes.append(node_id)

    def deregister_node(self, node_id: str) -> None:
        """Remove a node from the pool of available nodes."""
        if node_id in self.available_nodes:
            self.available_nodes.remove(node_id)

    def select_failover_node(self) -> Optional[str]:
        """Return the ID of a node to which work should be failovered."""
        return self.available_nodes[0] if self.available_nodes else None

