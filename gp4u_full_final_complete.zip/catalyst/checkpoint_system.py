"""
Checkpoint system.

This module implements a simple checkpointing mechanism for long‑running
jobs. It allows saving and restoring arbitrary job state to support
failover and recovery. For demonstration purposes the state is saved
using the ``StorageService`` from the backend and keyed by a unique
identifier.
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, Any

from backend.services.storage_service import StorageService


class CheckpointSystem:
    """Persist and restore job state for resilience."""

    def __init__(self, storage: StorageService) -> None:
        self.storage = storage

    async def create_checkpoint(self, job_id: str, state: Dict[str, Any]) -> str:
        """Save the given state and return a checkpoint ID."""
        checkpoint_id = f"{job_id}_{int(datetime.utcnow().timestamp())}"
        data = {
            "job_id": job_id,
            "timestamp": datetime.utcnow().isoformat(),
            "state": state,
        }
        await self.storage.save(checkpoint_id, data)
        return checkpoint_id

    async def restore_from_checkpoint(self, checkpoint_id: str) -> Dict[str, Any]:
        """Load state from a previously created checkpoint."""
        data = await self.storage.load(checkpoint_id)
        return data.get("state", {})

