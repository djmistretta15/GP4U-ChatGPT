"""
Node operator manager.

Manages registration and communication with GPU node operators. In a
decentralised network like Catalyst, each node is operated by an
independent party. This class provides methods to onboard new
operators, update their available GPUs and remove them from the
network.
"""

from __future__ import annotations

from typing import Dict, List


class NodeOperatorManager:
    """Manage node operators and their registered GPUs."""

    def __init__(self) -> None:
        self.operators: Dict[str, List[str]] = {}

    def register_operator(self, operator_id: str) -> None:
        """Add a new operator to the network."""
        if operator_id not in self.operators:
            self.operators[operator_id] = []

    def add_gpu_to_operator(self, operator_id: str, gpu_id: str) -> None:
        """Associate a GPU with an operator."""
        if operator_id not in self.operators:
            self.register_operator(operator_id)
        if gpu_id not in self.operators[operator_id]:
            self.operators[operator_id].append(gpu_id)

    def remove_gpu_from_operator(self, operator_id: str, gpu_id: str) -> None:
        """Remove a GPU association from an operator."""
        if operator_id in self.operators and gpu_id in self.operators[operator_id]:
            self.operators[operator_id].remove(gpu_id)

    def deregister_operator(self, operator_id: str) -> None:
        """Completely remove an operator and their GPUs."""
        self.operators.pop(operator_id, None)

