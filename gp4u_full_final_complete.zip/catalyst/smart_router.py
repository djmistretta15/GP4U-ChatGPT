"""
Smart router.

Routes jobs to the most appropriate GPU in the Catalyst network based
on job requirements and available hardware. This naive implementation
scales from the template provided in ``FILE_TEMPLATES.md`` and uses a
simple scoring function that ranks GPUs by memory and price. More
advanced versions could incorporate ML models to predict performance.
"""

from __future__ import annotations

from typing import List, Dict, Any


class SmartRouter:
    """Route compute jobs to GPUs based on simple heuristics."""

    async def route_job(self, job_requirements: Dict[str, Any], available_gpus: List[Dict[str, Any]]) -> str:
        """Select the best GPU for a job based on memory and price."""
        if not available_gpus:
            raise ValueError("No GPUs available for routing")
        gpu_scores: List[tuple[str, float]] = []
        for gpu in available_gpus:
            score = self._calculate_gpu_score(gpu, job_requirements)
            gpu_scores.append((gpu["id"], score))
        gpu_scores.sort(key=lambda x: x[1], reverse=True)
        return gpu_scores[0][0]

    def _calculate_gpu_score(self, gpu: Dict[str, Any], requirements: Dict[str, Any]) -> float:
        """Compute a heuristic score for a GPU.

        Scores are higher for GPUs with greater memory and lower price. The
        requirements dict may include a minimum memory (``min_memory``)
        and maximum price (``max_price``). GPUs that do not meet the
        minimum memory receive a very low score.
        """
        memory = gpu.get("memory_gb", 0)
        price = gpu.get("price_per_hour", 0)
        min_memory = requirements.get("min_memory", 0)
        max_price = requirements.get("max_price", float("inf"))
        if memory < min_memory or price > max_price:
            return 0.0
        # Score weighted by memory (positive) and price (negative)
        return memory / (price + 1e-3)

